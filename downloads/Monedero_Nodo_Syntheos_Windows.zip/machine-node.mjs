import {createServer} from 'node:https';
import {timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {availableParallelism, freemem, totalmem} from 'node:os';
import {join} from 'node:path';
import {GPU_PROFILE, ResourceNode, SLOT} from './compute/resource-pool.mjs';
import {readGpuInventoryAsync} from './compute/gpu-inventory.mjs';
import {enrollSharedGpu, sharedGpuHandler} from './compute/shared-gpu.mjs';
import {MODE, miningHash, requireThat} from './sil-ledger.mjs';

const HASH_ID=/^[a-f0-9]{32}$/;
const TOKEN=/^[A-Za-z0-9_-]{32,128}$/;
const MIB=1024*1024;
const isUnavailable=new Set(['worker_must_opt_in','insufficient_chronos','worker_already_reserved','local_resource_busy',
  'worker_opt_in_withdrawn','reservation_closed','worker_timeout','worker_exited']);

function reply(response, status, payload) {
  response.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});
  response.end(JSON.stringify(payload));
}

export function peerSettings(origin,token) {
  if(!origin)return null;
  const url=new URL(origin);
  requireThat(url.protocol==='https:'&&url.pathname==='/'&&!url.username&&!url.password&&!url.search&&!url.hash,
    'origen_micelial_invalido');
  requireThat(TOKEN.test(token??''),'token_micelial_invalido');
  return {origin:url.origin,headers:{Authorization:'Bearer '+token}};
}

export class MachineNode {
  constructor(home) {
    this.pools=new Map(['A','B'].map(name=>[name,new ResourceNode(join(home,'mycelial',name))]));
    const coordinator=this.pools.get('A').coordinator();
    this.id='myn_'+coordinator.id;
    for(const pool of this.pools.values()){
      pool.trustManager(pool.coordinator());
      if(!pool.get('pool',null)?.credits){
        try { pool.allocateDemoChronos(32); }
        catch(error){if(error.message!=='demo_chronos_already_initialized')throw error;}
      }
    }
  }
  close(){for(const pool of this.pools.values())pool.close();}
  pool(name){
    const pool=this.pools.get(name);
    requireThat(pool,'perfil_desconocido');
    return pool;
  }
  earnings(name){return this.pool(name).rewardReceipts();}
  cpuSharing(name,enabled){return this.pool(name).offerCpu(enabled);}
  gpuSharing(enabled){return enabled?enrollSharedGpu(this.pool('A')):this.pool('A').offerGpu(false);}
  async gpuInventory(){
    if(!this.gpuCache||Date.now()-this.gpuCache.at>=30000){
      this.gpuCache={at:Date.now(),value:readGpuInventoryAsync()};
    }
    return this.gpuCache.value;
  }

  roles({networkReady=false}={}) {
    const owner=this.pool('A').status();
    const pools=[owner,this.pool('B').status()];
    const machineBusy=(this.pool('A').get('unified_cpu_lease',null)?.expiresAt??0)>Date.now();
    const available=freemem();
    return {id:this.id,mode:MODE,
      resources:{logicalCPU:availableParallelism(),ramTotalMiB:Math.floor(totalmem()/MIB),ramAvailableMiB:Math.floor(available/MIB)},
      cpuShared:owner.host.sharesCpu,gpuShared:owner.host.sharesGpu,
      roles:[
        {name:'Coordinador',state:'LISTO',response:{chronosDisponibles:owner.availableChronos,
          chronosReservados:pools.reduce((sum,pool)=>sum+pool.reservedChronos,0)}},
        {name:'Trabajador',state:pools.some(pool=>pool.host.sharesCpu||pool.host.sharesGpu)?'OFERTA_ACTIVA':'EN_PAUSA',response:{
          redPrivada:networkReady,cpu:owner.host.sharesCpu,gpu:owner.host.sharesGpu,
          cpuPruebaLocal:pools[1].host.sharesCpu,cpuDisponible:owner.host.sharesCpu&&owner.availableChronos>=SLOT&&!machineBusy,
          gpuDisponible:owner.host.sharesGpu&&owner.availableChronos>=SLOT}},
        {name:'Almacenamiento',state:'LISTO',response:{recibos:this.pool('A').earnings().acceptedJobs+
          this.pool('B').earnings().acceptedJobs,medio:'SQLite persistente'}},
      ],
    };
  }

  async cpuJob(name,batch) {
    const pool=this.pool(name);
    const existing=pool.cpuReceipt(batch);
    if(existing)return {proof:existing.proof.outputSha256,receipt:existing.receipt,nodeId:this.id};
    return this.withCpu(async()=>{
      const offer=pool.workerOffer();
      pool.addWorker(offer);
      const {tickets}=pool.reserve('G0_MANIFEST_CHECK',[offer.id],batch);
      try {
        const proof=await pool.contribute(tickets[0]);
        const receipt=pool.collect(pool.settle(proof));
        return {proof:proof.outputSha256,receipt,nodeId:this.id};
      } catch(error) {
        pool.cancel(batch);
        throw error;
      }
    });
  }

  async withCpu(work) {
    const coordinator=this.pool('A');
    const key='unified_cpu_lease';
    const lease=coordinator.claimResource(key);
    try {
      return await work();
    } finally { coordinator.releaseResource(key,lease); }
  }

  listen({cert,key,token,port,host}) {
    requireThat(TOKEN.test(token??''),'token_micelial_invalido');
    const expected=Buffer.from('Bearer '+token);
    const gpu=sharedGpuHandler({provider:this.pool('A'),token});
    let busy=false;
    const server=createServer({cert,key,minVersion:'TLSv1.2',headersTimeout:5000,requestTimeout:10000},async(request,response)=>{
      const actual=Buffer.from(request.headers.authorization??'');
      if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return reply(response,401,{error:'no_autorizado'});
      if(request.method==='GET'&&request.url==='/v1/node')return reply(response,200,this.roles({networkReady:true}));
      if(request.url==='/v1/gpu'||request.url.startsWith('/v1/gpu/'))return gpu(request,response);
      const path=/^\/mycelial\/proof\/([a-f0-9]{32})$/.exec(request.url);
      if(!path)return reply(response,404,{error:'ruta_desconocida'});
      if(request.method==='GET'){
        try {
          const saved=this.pool('A').cpuReceipt(path[1]);
          return saved?reply(response,200,{proof:saved.proof.outputSha256,receipt:saved.receipt,nodeId:this.id})
            :reply(response,busy?409:404,{error:'recibo_no_disponible'});
        } catch {return reply(response,503,{error:'recibo_no_disponible'});}
      }
      if(request.method!=='POST'||request.headers['transfer-encoding']||Number(request.headers['content-length']??0)!==0){
        return reply(response,400,{error:'tarea_no_admitida'});
      }
      if(busy)return reply(response,429,{error:'worker_ocupado'});
      busy=true;
      try {return reply(response,200,await this.cpuJob('A',path[1]));}
      catch(error){return reply(response,isUnavailable.has(error.message)?409:503,{error:'trabajo_no_disponible'});}
      finally {busy=false;}
    });
    return server.listen(port,host);
  }
}

export function nodeListenerConfiguration(env=process.env) {
  if(!env.SYNTHEOS_MYCELIAL_CERT&&!env.SYNTHEOS_MYCELIAL_KEY)return null;
  requireThat(env.SYNTHEOS_MYCELIAL_CERT&&env.SYNTHEOS_MYCELIAL_KEY,'certificado_y_clave_requeridos');
  const port=Number(env.SYNTHEOS_MYCELIAL_PORT??8751);
  requireThat(Number.isInteger(port)&&port>=1024&&port<=65535,'puerto_invalido');
  return {cert:readFileSync(env.SYNTHEOS_MYCELIAL_CERT),key:readFileSync(env.SYNTHEOS_MYCELIAL_KEY),
    token:env.SYNTHEOS_MYCELIAL_TOKEN,port,host:env.SYNTHEOS_MYCELIAL_BIND??'127.0.0.1'};
}

export async function observePeer(peer,request=fetch) {
  if(!peer)return {type:'HTTP local',state:'SOLO_LOCAL',response:'sin par HTTPS configurado'};
  try {
    const response=await request(peer.origin+'/v1/node',{headers:peer.headers,redirect:'error',signal:AbortSignal.timeout(2200)});
    if(!response.ok)return {type:'HTTPS autenticado',state:'ERROR',status:response.status};
    const body=await response.json();
    requireThat(body.mode===MODE&&/^myn_[a-f0-9]{32}$/.test(body.id)&&body.roles?.length===3,'respuesta_micelial_invalida');
    return {type:'HTTPS autenticado',state:'CONECTADO',status:response.status,
      response:{id:body.id,roles:body.roles.map(role=>({name:role.name,state:role.state,response:role.response}))}};
  } catch {return {type:'HTTPS autenticado',state:'SIN_RESPUESTA'};}
}

export async function peerCpuProof(peer, id, {bound,bind=()=>{},request=fetch}={}) {
  requireThat(HASH_ID.test(id),'id_invalido');
  if(!peer){requireThat(!bound,'recibo_micelial_pendiente');return null;}
  const health=await observePeer(peer,request);
  const target='peer:'+health.response?.id;
  if(bound)requireThat(health.state==='CONECTADO'&&bound===target,'recibo_micelial_pendiente');
  else if(health.state!=='CONECTADO'||!health.response.roles.find(role=>role.name==='Trabajador')?.response?.cpuDisponible)return null;
  const url=peer.origin+'/mycelial/proof/'+id;
  async function get(method,timeout){
    return request(url,{method,headers:peer.headers,redirect:'error',signal:AbortSignal.timeout(timeout)});
  }
  async function read(response){
    const data=await response.json();
    requireThat(data.nodeId===health.response.id&&data.receipt?.batch===id&&data.proof===miningHash(id),'recibo_micelial_invalido');
    const work=data.receipt.work;
    if(work)requireThat(work.protocol==='PoUW'&&work.purpose==='G0_MANIFEST_CHECK'&&work.count===1&&
      typeof data.receipt.id==='string'&&HASH_ID.test(data.receipt.id)&&data.receipt.outputSha256===data.proof,
    'recibo_pouw_invalido');
    return {proof:data.proof,compute:'MYCELIAL',...(work?{workReceiptId:data.receipt.id}:{})};
  }
  if(bound){
    try {
      const saved=await get('GET',2200);
      if(saved.ok)return await read(saved);
      requireThat(saved.status===404,'recibo_micelial_pendiente');
    } catch {throw new Error('recibo_micelial_pendiente');}
  }
  bind(target);
  try {
    const reply=await get('POST',9000);
    if(!bound&&(reply.status===409||reply.status===429)){bind(null);return null;}
    if(reply.ok)return await read(reply);
  } catch { /* A request may have reached the provider. Check its persistent receipt first. */ }
  try {
    const recovery=await get('GET',2200);
    if(recovery.ok)return await read(recovery);
  } catch { /* The original settlement is still unknown. */ }
  throw new Error('recibo_micelial_pendiente');
}
