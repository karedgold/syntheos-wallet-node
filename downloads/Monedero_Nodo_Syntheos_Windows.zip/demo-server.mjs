import {createServer} from 'node:http';
import {randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {mkdirSync, readFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
import {once} from 'node:events';
import {SilLedger, requireThat} from './sil-ledger.mjs';
import {WalletClient} from './wallet-client.mjs';
import {cpuProof} from './mycelial-port.mjs';
import {MachineNode,nodeListenerConfiguration,observePeer,peerCpuProof,peerSettings} from './machine-node.mjs';
import {SymbioticCheckpointPilot, directSymbioticStatus} from './symbiotic-port.mjs';
import {createPortalReport} from './portal-report.mjs';

const publicFile=new Map([
  ['/',['index.html','text/html; charset=utf-8']], ['/wallet.js',['wallet.js','text/javascript; charset=utf-8']],
  ['/wallet.css',['wallet.css','text/css; charset=utf-8']], ['/portal-bridge.js',['portal-bridge.js','text/javascript; charset=utf-8']],
  ['/art/synt-g0.webp',['art/synt-g0.webp','image/webp']],
  ['/art/chronos.webp',['art/chronos.webp','image/webp']], ['/art/licencia.webp',['art/licencia.webp','image/webp']],
]);
function send(response, status, value) {
  response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  response.end(JSON.stringify(value));
}

async function readJson(request) {
  requireThat(request.headers['content-type']==='application/json','se_requiere_json');
  const chunks=[];
  let size=0;
  for await(const chunk of request){
    size+=chunk.length;
    requireThat(size<=8192,'solicitud_demasiado_grande');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

export async function startWalletDemo({directory, port=0, directOrigin, peerOrigin, peerToken, listener, listenerError}={}) {
  let peer,peerError=false;
  try {peer=peerSettings(peerOrigin,peerToken);}catch{peerError=true;}
  mkdirSync(directory,{recursive:true,mode:0o700});
  const ledger=new SilLedger(join(directory,'sil.sqlite'));
  const wallet=new WalletClient(join(directory,'wallet.sqlite'));
  const symbiotic=new SymbioticCheckpointPilot(join(directory,'symbiotic-pilot.sqlite'));
  const node=new MachineNode(directory);
  let silOnline=true, syncAvailable=false, origin, nodeServer;
  let networkState=listenerError?'ERROR_LOCAL':'SOLO_LOCAL';
  const serviceSecret=randomBytes(32).toString('hex');
  const profiles=['A','B'];
  for(const name of profiles){
    const profile=wallet.profile(name);
    ledger.provision(profile.identity.address,name==='A');
    node.cpuSharing(name,Boolean(profile.sharing));
  }
  if(listener){
    try {
      nodeServer=node.listen(listener);
      await once(nodeServer,'listening');
      networkState='ESCUCHANDO';
    } catch {
      nodeServer?.close();
      nodeServer=undefined;
      networkState='ERROR_LOCAL';
    }
  }

  async function serviceCall(path, options={}) {
    try {
      const response=await fetch(origin+path,{...options,headers:{...options.headers,'x-pilot-service':serviceSecret},
        signal:AbortSignal.timeout(9000),redirect:'error'});
      return response.status>=500?null:await response.json();
    } catch { return null; }
  }
  const sil={stage:intent=>serviceCall('/sil/intent',{method:'POST',body:JSON.stringify(intent),headers:{'Content-Type':'application/json'}}),
    snapshot:address=>serviceCall('/sil/snapshot/'+address)};
  const compute=async(id,address,bound,bind)=>{
    if(!bound||bound.startsWith('peer:')){
      const external=await peerCpuProof(peer,id,{bound,bind});
      if(external)return external;
    }
    const volunteer=bound?{name:bound.slice('local:'.length)}:
      wallet.profiles().find(profile=>profile.sharing&&wallet.view(profile.name).address!==address);
    if(volunteer){
      bind('local:'+volunteer.name);
      try {
        const {proof,receipt}=await node.cpuJob(volunteer.name,id);
        return {proof,compute:'MYCELIAL',...(receipt.work?{workReceiptId:receipt.id}:{})};
      }
      catch(error){
        if(bound||!['insufficient_chronos','worker_already_reserved','local_resource_busy','worker_must_opt_in',
          'worker_opt_in_withdrawn','worker_timeout','worker_exited'].includes(error.message))throw error;
        bind(null);
      }
    }
    return {proof:await node.withCpu(()=>cpuProof(id)),compute:'CPU_LOCAL'};
  };

  const view=()=>({profiles:profiles.map(name=>{
    const current=wallet.view(name);
    const receipts=node.earnings(name);
    return {name,...current,pendingRewards:Math.max(0,receipts.reduce((sum,receipt)=>sum+receipt.rewardFSynt,0)
      -(current.earnings?.fragments??0)),usefulWork:ledger.usefulWorkAccount(current.address,receipts)};
  }),
    sil:silOnline?'EN_LINEA':'SIN_CONEXION',symbiotic:syncAvailable?'RECEPTOR_PILOTO_DISPONIBLE':'SIN_CONEXION',
    season:'G0',node:node.roles({networkReady:Boolean(nodeServer)})});

  async function synchronize(){
    for(const name of profiles){
      node.pool(name).recoverLocalRewards();
      if(silOnline){
        const address=wallet.view(name).address;
        for(const receipt of node.earnings(name))ledger.creditCompute(address,receipt);
      }
      await wallet.sync(name,sil);
    }
  }

  async function observations(){
    const [silReply,symbioticReply,mycelialReply,gpu]=await Promise.all([
      readSilHealth(),directSymbioticStatus(directOrigin),observePeer(peer),node.gpuInventory(),
    ]);
    return {checkedAt:new Date().toISOString(),links:{
      Symbiotic:{type:'HTTPS directo · lectura',state:symbioticReply.direct,status:symbioticReply.status,response:symbioticReply},
      SIL:{type:'HTTP local · libro piloto',state:silReply.ok?'CONECTADO':silReply.status?'NO_DISPONIBLE':'SIN_RESPUESTA',
        status:silReply.status,response:silReply},
      Mycelial:peerError?{type:'HTTPS autenticado',state:'ERROR',listener:networkState,response:'configuración de par inválida'}:
        {...mycelialReply,listener:networkState,response:mycelialReply.response??{state:networkState}},
    },gpu:{estado:gpu.estado,adaptadores:gpu.adaptadores}};
  }

  async function readSilHealth(){
    try {
      const response=await fetch(origin+'/sil/health',{headers:{'x-pilot-service':serviceSecret},
        redirect:'error',signal:AbortSignal.timeout(1500)});
      return {status:response.status,...await response.json()};
    } catch {return {ok:false};}
  }
  let pendingMutation=Promise.resolve();
  function serialized(action){
    const run=pendingMutation.then(action);
    pendingMutation=run.catch(()=>{});
    return run;
  }

  async function route(request,response) {
    const path=request.url;
    if(request.headers.host!==new URL(origin).host)return send(response,403,{error:'origen_no_permitido'});
    const method=request.method;
    if(path.startsWith('/sil/')||path==='/symbiotic-pilot/checkpoint') {
      if(request.headers['x-pilot-service']!==serviceSecret)return send(response,403,{error:'servicio_privado'});
      if(path.startsWith('/sil/')) {
        if(!silOnline)return send(response,503,{error:'sin_conexion_sil'});
        if(method==='GET'&&path==='/sil/health')return send(response,200,{ok:true,mode:'SIMULATION_ONLY',service:'sil-wallet'});
        if(method==='GET'&&/^\/sil\/snapshot\/synw_[a-f0-9]{32}$/.test(path))return send(response,200,ledger.snapshot(path.split('/').at(-1)));
        if(method==='POST'&&path==='/sil/intent'){
          const intent=await readJson(request);
          try { return send(response,200,{accepted:true,receipt:ledger.stage(intent)}); }
          catch(error){ return send(response,409,{accepted:false,error:error.message}); }
        }
      }
      if(method==='POST'&&path==='/symbiotic-pilot/checkpoint'){
        if(!syncAvailable)return send(response,503,{error:'sin_conexion_symbiotic'});
        return send(response,200,symbiotic.checkpoint(await readJson(request)));
      }
      return send(response,404,{error:'ruta_desconocida'});
    }
    if(method==='GET'&&publicFile.has(path)) {
      const [file,type]=publicFile.get(path);
      response.writeHead(200,{'Content-Type':type,'X-Content-Type-Options':'nosniff',
        'Content-Security-Policy':"default-src 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'"});
      response.end(readFileSync(new URL('./public/'+file,import.meta.url)));
      return;
    }
    if(path==='/api/state'&&method==='GET')return send(response,200,view());
    if(path==='/api/pouw/report'&&method==='POST') {
      if(request.headers.origin!==origin)return send(response,403,{error:'origen_no_permitido'});
      const {profile}=await readJson(request);
      requireThat(profiles.includes(profile),'perfil_desconocido');
      const {address}=wallet.view(profile);
      const work=ledger.usefulWorkAccount(address,node.earnings(profile));
      return send(response,200,createPortalReport(profile,node,work));
    }
    if(path==='/api/action'&&method==='POST') {
      if(request.headers.origin!==origin)return send(response,403,{error:'origen_no_permitido'});
      const {name,action,payload}=await readJson(request);
      return serialized(async()=>{
        if(action==='conexion-sil')silOnline=payload.enabled===true;
        else if(action==='conexion-checkpoint')syncAvailable=payload.enabled===true;
        else if(action==='gpu-compartir'){
          requireThat(typeof payload.enabled==='boolean','permiso_de_computo_invalido');
          await node.gpuSharing(payload.enabled);
        } else if(action==='checkpoint'){
          const batch=ledger.nextCheckpoint();
          if(batch){
            const receipt=await serviceCall('/symbiotic-pilot/checkpoint',{method:'POST',headers:{'Content-Type':'application/json'},
              body:JSON.stringify(batch)});
            if(receipt)ledger.markCheckpoint(batch,receipt);
          }
        } else if(action!=='sincronizar') {
          requireThat(['minar','enviar','compartir'].includes(action),'accion_desconocida');
          await wallet.queue(name,action,payload,compute);
          if(action==='compartir')node.cpuSharing(name,payload.enabled);
        }
        await synchronize();
        return send(response,200,view());
      });
    }
    if(path==='/api/symbiotic'&&method==='GET')return send(response,200,await directSymbioticStatus(directOrigin));
    if(path==='/api/observacion'&&method==='GET')return send(response,200,await observations());
    return send(response,404,{error:'ruta_desconocida'});
  }

  const server=createServer({requestTimeout:10000,headersTimeout:5000},(request,response)=>{
    route(request,response).catch(error=>{if(!response.headersSent)send(response,400,{error:error.message});});
  });
  server.listen(port,'127.0.0.1');
  await once(server,'listening');
  origin=`http://127.0.0.1:${server.address().port}`;
  await synchronize();
  const interval=setInterval(()=>{void serialized(synchronize).catch(()=>{});},5000);
  interval.unref();
  return {origin,nodeAddress:nodeServer?.address(),async close(){
    clearInterval(interval);
    const closedNode=nodeServer?new Promise(resolve=>nodeServer.close(resolve)):null;
    const ended=new Promise(resolve=>server.close(resolve));
    await Promise.all([ended,closedNode]);
    await pendingMutation;
    wallet.close();ledger.close();symbiotic.close();node.close();
  }};
}

if(process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href){
  const directory=process.env.SYNTHEOS_WALLET_HOME??join(process.env.LOCALAPPDATA??tmpdir(),'Syntheos','Wallet-SIL-Pilot');
  const port=Number(process.env.SYNTHEOS_WALLET_PORT??8750);
  requireThat(Number.isInteger(port)&&port>=1024&&port<=65535,'puerto_invalido');
  let listener,listenerError=false;
  try {listener=nodeListenerConfiguration();}catch{listenerError=true;}
  const app=await startWalletDemo({directory,port,listener,listenerError,
    directOrigin:process.env.SYNTHEOS_SYMBIOTIC_ORIGIN??'https://syntheos-symbiotic-main.onrender.com',
    peerOrigin:process.env.SYNTHEOS_MYCELIAL_PROOF_ORIGIN,peerToken:process.env.SYNTHEOS_MYCELIAL_TOKEN});
  console.log('Monedero nodo de prueba · '+app.origin);
  if(process.platform==='win32'&&process.env.SYNTHEOS_WALLET_OPEN_BROWSER==='1'){
    const browser=spawn('explorer.exe',[app.origin],{stdio:'ignore',windowsHide:true,detached:true});
    browser.on('error',()=>{});
    browser.unref();
  }
  process.once('SIGINT',async()=>{await app.close();});
}
