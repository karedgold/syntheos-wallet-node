import {Worker} from 'node:worker_threads';
import {sha} from './resource-work.mjs';

export function cpuProof(id) {
  return new Promise((resolve,reject)=>{
    const worker=new Worker(new URL('./resource-work.mjs',import.meta.url),{
      workerData:{purpose:'G0_MANIFEST_CHECK',batch:id,index:0,count:1},
      resourceLimits:{maxOldGenerationSizeMb:24,stackSizeMb:2},
      execArgv:[],
    });
    const timeout=setTimeout(()=>{
      reject(new Error('trabajo_micelial_agotado'));
      void worker.terminate();
    },8000);
    worker.once('message',({result})=>{resolve(sha(result));void worker.terminate();});
    worker.once('error',reject);
    worker.once('exit',code=>{clearTimeout(timeout);if(code!==0)reject(new Error('trabajo_micelial_interrumpido'));});
  });
}
