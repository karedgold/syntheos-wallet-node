import {writeFileSync,mkdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {configuredProviders,recoverSharedRender,renderPreferred} from './compute/shared-gpu.mjs';
import {MachineNode} from './machine-node.mjs';
import {requireThat} from './sil-ledger.mjs';

const [command,path,batch]=process.argv.slice(2);
requireThat((command==='render'||command==='recover-render')&&path,'Uso: node Forge-Recursos.mjs render imagen.png');
const env=process.env;
const home=env.SYNTHEOS_WALLET_HOME??join(env.LOCALAPPDATA??tmpdir(),'Syntheos','Wallet-SIL-Pilot');
mkdirSync(home,{recursive:true,mode:0o700});
const node=new MachineNode(home);
const providers=configuredProviders({SYNTHEOS_GPU_URLS:env.SYNTHEOS_GPU_URLS??env.SYNTHEOS_MYCELIAL_PROOF_ORIGIN});
const token=env.SYNTHEOS_GPU_TOKEN??env.SYNTHEOS_MYCELIAL_TOKEN;
try {
  const {png,...receipt}=await (command==='recover-render'?recoverSharedRender({providers,token,batch}):
    renderPreferred({providers,token,gpu:ticket=>node.pool('A').renderLocalGpu(ticket)}));
  writeFileSync(path,png,{flag:'wx',mode:0o600});
  console.log(JSON.stringify({...receipt,file:path},null,2));
} finally {node.close();}
