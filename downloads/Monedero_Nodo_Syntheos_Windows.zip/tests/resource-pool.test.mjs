import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {ResourceNode} from '../compute/resource-pool.mjs';
import {previewPng, workFor} from '../compute/resource-work.mjs';
import {SilLedger,makeIdentity} from '../sil-ledger.mjs';

test('Chronos gates opt-in work, settlement and durable rewards', async () => {
  const root = mkdtempSync(join(tmpdir(), 'synt-resources-test-'));
  const coordinator = new ResourceNode(join(root, 'coordinator'));
  const worker = new ResourceNode(join(root, 'worker'));
  const anotherWorker = new ResourceNode(join(root, 'other'));
  try {
    assert.equal(worker.status().host.sharesCpu, false);
    assert.throws(() => worker.workerOffer(), /worker_must_opt_in/);
    const identity = coordinator.coordinator();
    const enrolled = [worker, anotherWorker].map(node => {
      node.trustManager(identity);
      node.offerCpu(true);
      return coordinator.addWorker(node.workerOffer()).acceptedWorker;
    });
    assert.throws(() => coordinator.reserve('FORGE_PREVIEW', enrolled), /insufficient_chronos/);
    coordinator.allocateDemoChronos(32);
    const {batch, tickets} = coordinator.reserve('FORGE_PREVIEW', enrolled);
    assert.equal(coordinator.status().reservedChronos, 16);
    await assert.rejects(worker.contribute(tickets[1]), /invalid_or_expired_lease/);
    await assert.rejects(worker.contribute({...tickets[0], chronos: 16}), /invalid_signature/);
    worker.offerCpu(false);
    await assert.rejects(worker.contribute(tickets[0]), /worker_must_opt_in/);
    worker.offerCpu(true);

    const proofs = await Promise.all([worker.contribute(tickets[0]), anotherWorker.contribute(tickets[1])]);
    assert.throws(() => coordinator.settle({...proofs[0], elapsedMs: 8000}), /invalid_signature/);
    const receipts = proofs.map(proof => coordinator.settle(proof));
    assert.deepEqual(coordinator.settle(proofs[0]), receipts[0]);
    assert.throws(() => anotherWorker.collect(receipts[0]), /settlement_binding_mismatch/);
    assert.deepEqual(worker.collect(receipts[0]), worker.collect(receipts[0]));
    assert.throws(()=>worker.collect({...receipts[0],work:{...receipts[0].work,count:1}}),/invalid_signature/);
    assert.equal(worker.earnings().rewardFSynt, 10);
    assert.equal(coordinator.status().rewardFSynt, 20);
    assert.equal(coordinator.status().reservedChronos, 0);

    const png = coordinator.exportPreview(batch);
    assert.equal(png.readUInt32BE(16), 640);
    assert.equal(png.readUInt32BE(20), 360);
    assert.deepEqual(png, previewPng([workFor({...tickets[0], index: 0, count: 1})]));
    const ledger=new SilLedger(':memory:');
    try {
      const {address}=makeIdentity();
      const half=ledger.usefulWorkAccount(address,worker.rewardReceipts()).summary;
      assert.equal(half.preview.pixels,115200);
      assert.equal(half.preview.attributedCostFSynt,10);
      assert.equal(half.genesis.fragments,0);
      const full=ledger.usefulWorkAccount(address,receipts).summary;
      assert.equal(full.preview.pixels,full.preview.pixelsPerPreview);
      assert.equal(full.preview.attributedCostFSynt,20);
      const old=ledger.usefulWorkAccount(address,[{rewardFSynt:10}]).summary;
      assert.equal(old.legacyJobs,1);
      assert.equal(old.computeCostFSynt,0);
    } finally {ledger.close();}

    const next = coordinator.reserve('G0_MANIFEST_CHECK', [enrolled[0]]);
    const proof = await worker.contribute(next.tickets[0]);
    assert.equal(coordinator.cancel(next.batch).releasedChronos, 8);
    assert.throws(() => coordinator.settle(proof), /reservation_closed/);
    assert.equal(coordinator.status().reservedChronos, 0);
    const reopened = new ResourceNode(join(root, 'worker'));
    try {
      assert.equal(reopened.earnings().acceptedJobs, 1);
      assert.equal(reopened.earnings().rewardFSynt, 10);
    } finally {
      reopened.close();
    }
  } finally {
    coordinator.close();
    worker.close();
    anotherWorker.close();
    rmSync(root, {recursive: true, force: true});
  }
});
