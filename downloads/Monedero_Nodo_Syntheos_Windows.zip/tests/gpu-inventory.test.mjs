import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readGpuInventory} from '../compute/gpu-inventory.mjs';

test('keeps both Windows adapters visible independently of compute support', () => {
  const result = readGpuInventory('win32', () => JSON.stringify([
    {Name: 'Intel HD Graphics 630', DriverVersion: '31.0.101.2115', ConfigManagerErrorCode: 0},
    {Name: 'NVIDIA GeForce GT 730', DriverVersion: '30.0.14.7444', ConfigManagerErrorCode: 22},
  ]));
  assert.equal(result.aceleracion_gpu, 'no habilitada en el piloto');
  assert.deepEqual(result.adaptadores, [
    {nombre: 'Intel HD Graphics 630', version_controlador: '31.0.101.2115', codigo_dispositivo_windows: 0},
    {nombre: 'NVIDIA GeForce GT 730', version_controlador: '30.0.14.7444', codigo_dispositivo_windows: 22},
  ]);
});

test('distinguishes an empty Windows inventory from a failed query', () => {
  const empty = readGpuInventory('win32', () => '\uFEFF[]');
  const failure = readGpuInventory('win32', () => {throw new Error('CIM unavailable');});
  assert.deepEqual(empty.adaptadores, []);
  assert.notEqual(empty.estado, failure.estado);
  assert.deepEqual(readGpuInventory('win32', () => 'invalid output'), failure);
  assert.equal(readGpuInventory('linux').estado, 'consulta disponible en Windows');
});
