import assert from 'node:assert/strict';
import {once} from 'node:events';
import {mkdtempSync, rmSync} from 'node:fs';
import {createServer} from 'node:http';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {ResourceNode} from '../compute/resource-pool.mjs';
import {workFor} from '../compute/resource-work.mjs';
import {enrollSharedGpu, recoverSharedRender, renderPreferred, sharedGpuHandler} from '../compute/shared-gpu.mjs';

const token = 'x'.repeat(48);
const referenceGpu = async ticket => ({result: workFor(ticket), elapsedMs: 1000});

test('shared provider bills once, returns the same pixels and then falls back locally', async () => {
  const directory = mkdtempSync(join(tmpdir(), 'synt-gpu-test-'));
  const provider = new ResourceNode(directory);
  const started = Promise.withResolvers();
  const release = Promise.withResolvers();
  const server = createServer(sharedGpuHandler({provider, token, gpu: async ticket=>{
    started.resolve();
    await release.promise;
    return referenceGpu(ticket);
  }}));
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  const providers = [base];
  try {
    await assert.rejects(enrollSharedGpu(provider, async()=>({result: Buffer.alloc(1)})), /gpu_no_verificada/);
    assert.equal((await fetch(base+'/v1/gpu')).status, 401);
    assert.equal(provider.status().host.sharesGpu, false);
    await enrollSharedGpu(provider, referenceGpu);
    const auth = {headers:{Authorization:'Bearer '+token}};
    assert.equal((await (await fetch(base+'/v1/gpu',auth)).json()).available, false);
    provider.allocateDemoChronos(8);

    const batch = 'abc1'.repeat(8);
    const render = renderPreferred({providers, token, batch, gpu:async()=>{assert.fail('local GPU used');}});
    await started.promise;
    try {
      assert.equal(provider.status().reservedChronos, 8);
      await assert.rejects(provider.renderLocalGpu({}), /local_resource_busy/);
      assert.equal((await fetch(base+'/v1/gpu/'+'d'.repeat(32),{...auth, method:'POST'})).status, 429);
    } finally { release.resolve(); }
    const remote = await render;
    assert.equal(remote.source, 'gpu_compartida');
    assert.equal(remote.receipt.consumedChronos, 1);
    assert.equal(remote.receipt.releasedChronos, 7);
    assert.equal(remote.receipt.rewardFSynt, 10);
    assert.equal(provider.earnings().acceptedJobs, 1);

    assert.equal((await fetch(base+'/v1/gpu/'+batch,{...auth, method:'POST'})).status, 200);
    assert.equal(provider.earnings().acceptedJobs, 1);
    const recovered = await recoverSharedRender({providers,token,batch});
    assert.deepEqual(recovered.receipt,remote.receipt);
    assert.deepEqual(recovered.png,remote.png);

    const local = await renderPreferred({providers,token,batch,gpu:referenceGpu});
    assert.equal(local.source,'gpu_local');
    assert.deepEqual(local.png,remote.png);
    const cpu = await renderPreferred({providers,token,batch,gpu:async()=>{throw new Error('no GPU');}});
    assert.equal(cpu.source,'cpu_local');
    assert.deepEqual(cpu.png,remote.png);
    assert.equal(provider.status().reservedChronos,0);
    assert.equal(provider.status().consumedChronos,1);
  } finally {
    release.resolve();
    await new Promise(resolve=>server.close(resolve));
    provider.close();
    rmSync(directory,{recursive:true,force:true});
  }
});

test('rejects an ambiguous remote settlement without dispatching a second job', async () => {
  const batch = '1'.repeat(32);
  const endpoints=[];
  await assert.rejects(renderPreferred({providers:['https://a.invalid','https://b.invalid'],token,batch,
    fetcher:async (url,options)=>{
      endpoints.push(url);
      if(options.method==='POST')throw new Error('lost response');
      return new Response(JSON.stringify({mode:'SIMULATION_ONLY',profile:'opencl-preview-pilot-v1',available:true}));
    },gpu:async()=>{assert.fail('local job started while the remote receipt was pending');}}),
  /liquidacion_remota_sin_confirmar/);
  assert.equal(endpoints.length,2);
  assert.ok(endpoints.every(url=>new URL(url).hostname==='a.invalid'));
});
