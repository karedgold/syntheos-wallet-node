import assert from 'node:assert/strict';
import {mkdtempSync, rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {test} from 'node:test';
import {startWalletDemo} from '../demo-server.mjs';
import {SilLedger, makeIdentity, signIntent} from '../sil-ledger.mjs';
import {SymbioticCheckpointPilot, directSymbioticStatus} from '../symbiotic-port.mjs';
import {peerCpuProof} from '../machine-node.mjs';
import {miningHash} from '../sil-ledger.mjs';

test('two wallets mine, share and transfer despite a Symbiotic outage',async()=>{
  const directory=mkdtempSync(join(tmpdir(),'synt-wallet-test-'));
  let app=await startWalletDemo({directory});
  const request=(name,action,payload={})=>fetch(app.origin+'/api/action',{method:'POST',headers:{
    Origin:app.origin,'Content-Type':'application/json'},body:JSON.stringify({name,action,payload})});
  const get=async()=>await (await fetch(app.origin+'/api/state')).json();
  try {
    assert.equal((await fetch(app.origin+'/sil/snapshot/synw_'+'0'.repeat(32))).status,403);
    assert.equal((await get()).symbiotic,'SIN_CONEXION');
    const initial=await get();
    const nodeId=initial.node.id;
    assert.match(nodeId,/^myn_[a-f0-9]{32}$/);
    assert.deepEqual(initial.node.roles.map(role=>role.name),['Coordinador','Trabajador','Almacenamiento']);
    assert.ok(initial.node.resources.ramTotalMiB>0);
    const observe=async()=>await (await fetch(app.origin+'/api/observacion')).json();
    const links=await observe();
    assert.equal(links.links.SIL.state,'CONECTADO');
    assert.equal(links.links.Mycelial.state,'SOLO_LOCAL');
    assert.equal(links.links.Symbiotic.state,'SIN_CONFIGURAR');
    assert.ok(Array.isArray(links.gpu.adaptadores));
    let state=await (await request('B','compartir',{enabled:true})).json();
    assert.equal(state.profiles[1].sharing,true);
    await request('A','conexion-sil',{enabled:false});
    const mine=await request('A','minar');
    state=await mine.json();
    assert.equal(mine.status,200,state.error);
    const pending=state.profiles[1].usefulWork;
    assert.equal(pending.summary.computeCostFSynt,10);
    assert.deepEqual(pending.summary.genesis,{fragments:0,attributedCostFSynt:0,attributedChronos:0,pendingJobs:1});
    assert.equal(pending.entries[0].credited,false);
    state=await (await request('A','conexion-sil',{enabled:true})).json();
    assert.equal(state.profiles[0].balance,1);
    assert.equal(state.profiles[0].chronos,15);
    assert.equal(state.profiles[0].locks.length,2);
    assert.equal(state.profiles[0].records[0].compute,'MYCELIAL');
    assert.equal(state.profiles[0].records[0].state,'ACEPTADO_EN_SIL');
    assert.equal(state.profiles[1].balance,10);
    assert.deepEqual(state.profiles[1].earnings,{jobs:1,fragments:10});
    assert.equal(state.profiles[1].records[0].action,'cobro');
    const useful=state.profiles[1].usefulWork;
    assert.equal(useful.summary.computeCostFSynt,10);
    assert.deepEqual(useful.summary.genesis,{fragments:1,attributedCostFSynt:10,attributedChronos:useful.entries[0].chronos,pendingJobs:0});
    assert.equal(useful.entries[0].credited,true);
    assert.equal(state.profiles[0].records[0].workReceiptId,useful.entries[0].id);
    assert.match(useful.entries[0].proofHash,/^[a-f0-9]{64}$/);
    assert.equal((await request('A','minar')).status,400);
    assert.equal(state.symbiotic,'SIN_CONEXION');

    await request('A','conexion-sil',{enabled:false});
    const unavailable=(await observe()).links.SIL;
    assert.equal(unavailable.state,'NO_DISPONIBLE');
    assert.equal(unavailable.status,503);
    const recipient=state.profiles[1].address;
    state=await (await request('A','enviar',{recipient,units:1})).json();
    assert.equal(state.profiles[0].outbox[0].state,'PENDIENTE_DE_SIL');
    assert.equal(state.profiles[0].available,0);
    assert.equal(state.profiles[1].balance,10);
    assert.equal((await request('A','enviar',{recipient,units:1})).status,400);

    await app.close();
    app=await startWalletDemo({directory});
    state=await get();
    assert.equal(state.node.id,nodeId);
    assert.equal(state.profiles[0].balance,0);
    assert.equal(state.profiles[0].outbox.length,0);
    assert.equal(state.profiles[1].balance,11);
    assert.deepEqual(state.profiles[1].earnings,{jobs:1,fragments:10});
    assert.deepEqual(state.profiles[1].usefulWork,useful);
    assert.equal(state.profiles[1].records[0].action,'enviar');
    assert.equal(state.profiles[1].records[0].state,'ACEPTADO_EN_SIL');
    await request('A','checkpoint');
    assert.equal((await get()).profiles[1].records[0].state,'ACEPTADO_EN_SIL');
    await request('A','conexion-checkpoint',{enabled:true});
    state=await (await request('A','checkpoint')).json();
    assert.equal(state.profiles[1].records[0].state,'CHECKPOINT_PILOTO');
    assert.equal(state.profiles[1].records[0].anchor.events,4);
    assert.equal((await (await request('A','checkpoint')).json()).profiles[1].balance,11);
  } finally { await app.close();rmSync(directory,{recursive:true,force:true}); }
});

test('signed replay is idempotent and a lost checkpoint response retains the original batch',()=>{
  const ledger=new SilLedger(':memory:');
  const symbiotic=new SymbioticCheckpointPilot(':memory:');
  try {
    const wallet=makeIdentity();
    ledger.provision(wallet.address,true);
    const intent=signIntent(wallet,'compartir',{enabled:true});
    assert.throws(()=>ledger.stage({...intent,payload:{enabled:false}}),/firma_invalida/);
    assert.deepEqual(ledger.stage(intent),ledger.stage(intent));
    assert.throws(()=>ledger.stage(signIntent(wallet,'compartir',{enabled:false},intent.id)),/operacion_en_conflicto/);
    const first=ledger.nextCheckpoint();
    const lostReceipt=symbiotic.checkpoint(first);
    ledger.stage(signIntent(wallet,'compartir',{enabled:false}));
    assert.deepEqual(ledger.nextCheckpoint(),first);
    assert.deepEqual(symbiotic.checkpoint(first),lostReceipt);
    assert.throws(()=>ledger.markCheckpoint(first,{...lostReceipt,hash:'0'.repeat(64)}),/recibo_checkpoint_invalido/);
    ledger.markCheckpoint(first,lostReceipt);
    const next=ledger.nextCheckpoint();
    assert.deepEqual(next.events.map(event=>event.seq),[2]);
    ledger.markCheckpoint(next,symbiotic.checkpoint(next));
    assert.equal(ledger.nextCheckpoint(),null);
  } finally { ledger.close();symbiotic.close(); }
});

test('direct status uses the known Symbiotic read path without requiring it for the wallet',async()=>{
  const status=await directSymbioticStatus('https://symbiotic.invalid',async(url,options)=>{
    assert.equal(url.pathname,'/healthz');
    assert.equal(options.method,undefined);
    return new Response(JSON.stringify({ok:true,service:'symbiotic-l1',version:'0.2.0'}));
  });
  assert.deepEqual(status,{direct:'SOLO_LECTURA',status:200,version:'0.2.0'});
  assert.deepEqual(await directSymbioticStatus('https://symbiotic.invalid',async()=>new Response('',{status:401})),
    {direct:'REQUIERE_AUTORIZACION',status:401});
});

test('an unresolved compute charge is retried against the same node and job',async()=>{
  const peer={origin:'https://mycelial.invalid'};
  const nodeId='myn_'+'a'.repeat(32);
  const id='b'.repeat(32);
  let bound,canRecover=false,posts=0;
  const request=async(url,options)=>{
    if(url.endsWith('/v1/node'))return Response.json({mode:'SIMULATION_ONLY',id:nodeId,roles:[{}, {},
      {name:'Trabajador',response:{cpuDisponible:!canRecover}}]});
    if(options.method==='POST'){posts++;throw new Error('respuesta_perdida');}
    if(canRecover)return Response.json({nodeId,proof:miningHash(id),receipt:{batch:id}});
    return new Response(null,{status:404});
  };
  await assert.rejects(peerCpuProof(peer,id,{bind:value=>{bound=value;},request}),/recibo_micelial_pendiente/);
  assert.equal(bound,'peer:'+nodeId);
  canRecover=true;
  assert.equal((await peerCpuProof(peer,id,{bound,request})).compute,'MYCELIAL');
  assert.equal(posts,1);
});
