@echo off
setlocal
where node.exe >nul 2>&1
if errorlevel 1 goto required
node.exe -e "process.exit(process.versions.node.startsWith('24.') ? 0 : 1)"
if errorlevel 1 goto required
set "SYNTHEOS_WALLET_OPEN_BROWSER=1"
node.exe "%~dp0demo-server.mjs"
if errorlevel 1 pause
exit /b %errorlevel%

:required
echo El monedero necesita Node.js 24 en PATH.
pause
exit /b 1
