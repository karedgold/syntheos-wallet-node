import {openDb, transact, makeIdentity, signIntent, requestId, MODE, requireThat} from './sil-ledger.mjs';

export class WalletClient {
  constructor(path) {
    this.db=openDb(path);
    this.db.exec(`CREATE TABLE IF NOT EXISTS profiles(name TEXT PRIMARY KEY, identity TEXT NOT NULL, snapshot TEXT NOT NULL,
      sharing INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS outbox(seq INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
      intent TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'PENDIENTE_DE_SIL', error TEXT);
      CREATE TABLE IF NOT EXISTS mining_jobs(name TEXT PRIMARY KEY,id TEXT NOT NULL,source TEXT);`);
  }
  close() { this.db.close(); }
  profiles() { return this.db.prepare('SELECT name,sharing FROM profiles ORDER BY name').all(); }

  profile(name) {
    requireThat(name==='A'||name==='B','perfil_desconocido');
    return transact(this.db,()=>{
      const prior=this.db.prepare('SELECT * FROM profiles WHERE name=?').get(name);
      if(prior)return {...prior,identity:JSON.parse(prior.identity),snapshot:JSON.parse(prior.snapshot)};
      const identity=makeIdentity();
      const snapshot={mode:MODE,address:identity.address,balance:0,chronos:0,founder:false,locks:[],records:[]};
      this.db.prepare('INSERT INTO profiles(name,identity,snapshot) VALUES (?,?,?)')
        .run(name,JSON.stringify(identity),JSON.stringify(snapshot));
      return {name,identity,snapshot,sharing:0};
    });
  }

  pending(name) {
    return this.db.prepare('SELECT intent,state,error FROM outbox WHERE name=? ORDER BY seq').all(name)
      .map(row=>({...row,intent:JSON.parse(row.intent)}));
  }

  async queue(name, action, payload, useCompute) {
    const profile=this.profile(name);
    let id=requestId();
    if(action==='minar') {
      const job=transact(this.db,()=>{
        requireThat(profile.snapshot.founder&&profile.snapshot.chronos>=1,'g0_requiere_fundador_y_chronos');
        requireThat(!profile.snapshot.g0Mined&&!profile.snapshot.records.some(row=>row.action==='minar')&&
          !this.pending(name).some(row=>row.intent.action==='minar'&&row.state==='PENDIENTE_DE_SIL'),'limite_g0_del_piloto');
        this.db.prepare('INSERT OR IGNORE INTO mining_jobs VALUES (?,?,NULL)').run(name,id);
        return this.db.prepare('SELECT id,source FROM mining_jobs WHERE name=?').get(name);
      });
      id=job.id;
      const bind=source=>this.db.prepare('UPDATE mining_jobs SET source=? WHERE name=? AND id=?').run(source,name,id);
      payload=await useCompute(id,profile.identity.address,job.source,bind);
    }
    return transact(this.db,()=>{
      const {identity, snapshot}=this.db.prepare('SELECT identity,snapshot FROM profiles WHERE name=?').get(name);
      if(action==='enviar'){
        const reserved=this.pending(name).filter(row=>row.state==='PENDIENTE_DE_SIL'&&row.intent.action==='enviar')
          .reduce((total,row)=>total+row.intent.payload.units,0);
        requireThat(Number.isSafeInteger(payload.units) && payload.units>0 && payload.units<=JSON.parse(snapshot).balance-reserved,
          'saldo_disponible_insuficiente');
      }
      if(action==='compartir') {
        requireThat(typeof payload.enabled==='boolean','permiso_de_computo_invalido');
        this.db.prepare('UPDATE profiles SET sharing=? WHERE name=?').run(payload.enabled?1:0,name);
      }
      const intent=signIntent(JSON.parse(identity),action,payload,id);
      this.db.prepare('INSERT INTO outbox(id,name,intent) VALUES (?,?,?)').run(id,name,JSON.stringify(intent));
      if(action==='minar')this.db.prepare('DELETE FROM mining_jobs WHERE name=? AND id=?').run(name,id);
      return id;
    });
  }

  async sync(name, sil) {
    const {identity}=this.profile(name);
    if(!sil)return false;
    const accepted=[];
    for(const {intent,state} of this.pending(name)) {
      if(state!=='PENDIENTE_DE_SIL')continue;
      const result=await sil.stage(intent);
      if(!result)return false;
      if(!result.accepted){
        this.db.prepare("UPDATE outbox SET state='RECHAZADO_POR_SIL',error=? WHERE id=?").run(result.error,intent.id);
      } else {
        requireThat(result.receipt.id===intent.id,'recibo_sil_no_coincide');
        accepted.push(intent.id);
      }
    }
    const snapshot=await sil.snapshot(identity.address);
    if(!snapshot)return false;
    requireThat(snapshot.address===identity.address && snapshot.mode===MODE,'snapshot_no_coincide');
    transact(this.db,()=>{
      for(const id of accepted)this.db.prepare('DELETE FROM outbox WHERE id=? AND name=?').run(id,name);
      this.db.prepare('UPDATE profiles SET snapshot=? WHERE name=?').run(JSON.stringify(snapshot),name);
    });
    return true;
  }

  view(name) {
    const {snapshot,sharing}=this.profile(name);
    const outbox=this.pending(name);
    const reserved=outbox.filter(row=>row.state==='PENDIENTE_DE_SIL'&&row.intent.action==='enviar')
      .reduce((total,row)=>total+row.intent.payload.units,0);
    return {...snapshot,available:Math.max(0,snapshot.balance-reserved),sharing:Boolean(sharing),
      outbox:outbox.map(row=>({id:row.intent.id,action:row.intent.action,state:row.state,error:row.error,
        ...(row.intent.action==='minar'?{compute:row.intent.payload.compute}:{})}))};
  }
}
