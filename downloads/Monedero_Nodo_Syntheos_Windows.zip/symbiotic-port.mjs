import {canonical, sha} from './resource-work.mjs';
import {MODE, NETWORK, openDb, requireThat, transact} from './sil-ledger.mjs';

export class SymbioticCheckpointPilot {
  constructor(path) {
    this.db=openDb(path);
    this.db.exec(`CREATE TABLE IF NOT EXISTS checkpoint(id TEXT PRIMARY KEY, receipt TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS committed_events(seq INTEGER PRIMARY KEY, hash TEXT NOT NULL, checkpoint TEXT NOT NULL);`);
  }
  close() { this.db.close(); }
  checkpoint(batch) {
    const {id,...body}=batch;
    requireThat(body.mode===MODE && body.network===NETWORK && body.schema==='syntheos.wallet-checkpoint-pilot/1' &&
      Array.isArray(body.events) && body.events.length>0 && body.events.length<=50 && id===sha(canonical(body)),
      'checkpoint_invalido');
    return transact(this.db,()=>{
      const prior=this.db.prepare('SELECT receipt FROM checkpoint WHERE id=?').get(id);
      if(prior)return JSON.parse(prior.receipt);
      const head=this.db.prepare('SELECT MAX(seq) AS head FROM committed_events').get().head??0;
      requireThat(body.events.every((event,index)=>event.seq===head+index+1 && /^[a-f0-9]{64}$/.test(event.hash)),
        'checkpoint_fuera_de_orden');
      const data={mode:MODE,schema:'syntheos.wallet-checkpoint-receipt-pilot/1',id,events:body.events.length,
        first:body.events[0].seq,last:body.events.at(-1).seq};
      const receipt={...data,hash:sha(canonical(data))};
      this.db.prepare('INSERT INTO checkpoint VALUES (?,?)').run(id,JSON.stringify(receipt));
      for(const event of body.events)this.db.prepare('INSERT INTO committed_events VALUES (?,?,?)').run(event.seq,event.hash,id);
      return receipt;
    });
  }
}

export async function directSymbioticStatus(origin, fetcher=fetch) {
  if(!origin)return {direct:'SIN_CONFIGURAR'};
  try {
    const base=new URL(origin);
    requireThat(base.protocol==='https:' && base.pathname==='/' && !base.username && !base.password && !base.search && !base.hash,
      'origen_symbiotic_invalido');
    const response=await fetcher(new URL('/healthz',base),{redirect:'error',signal:AbortSignal.timeout(2500)});
    if(response.status===401||response.status===403)return {direct:'REQUIERE_AUTORIZACION',status:response.status};
    if(!response.ok)return {direct:'NO_DISPONIBLE',status:response.status};
    const data=await response.json();
    return data.ok===true && data.service==='symbiotic-l1' && typeof data.version==='string'
      ?{direct:'SOLO_LECTURA',status:response.status,version:data.version}:{direct:'RESPUESTA_NO_RECONOCIDA',status:response.status};
  } catch { return {direct:'NO_DISPONIBLE'}; }
}
