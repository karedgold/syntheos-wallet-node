import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { isMainThread, parentPort, workerData } from 'node:worker_threads';

export const MAX_SHARDS = 4;
export const FIRST_MANIFEST = '21d77954c39aed67d3898269d5e9fcfb3c085003cf8bb287d1cbd00a019b6305';
export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const canonical = value => Array.isArray(value)
  ? '[' + value.map(canonical).join(',') + ']'
  : value && typeof value === 'object'
    ? '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}'
    : JSON.stringify(value);

export function assertThat(condition, message) {
  if (!condition) throw new Error(message);
}

export function workFor(ticket) {
  const { purpose, batch, index, count } = ticket;
  assertThat(Number.isInteger(index) && Number.isInteger(count) && count >= 1 &&
    count <= MAX_SHARDS && index >= 0 && index < count && /^[a-f0-9]{32}$/.test(batch), 'invalid_work');
  assertThat(purpose === 'G0_MANIFEST_CHECK', 'unsupported_work');
  const manifest = JSON.parse(readFileSync(new URL('first-fragment.json', import.meta.url)));
  const digest = sha(canonical(manifest));
  assertThat(digest === FIRST_MANIFEST && manifest.ordinal === '1' && manifest.quantity === '1', 'manifest_mismatch');
  let result = Buffer.from(['synt-g0-manifest-v1',batch,index,digest].join(':'));
  for (let round = 0; round < 25000; round++) result = createHash('sha256').update(result).digest();
  return result;
}

if (!isMainThread) {
  const start = performance.now();
  const result = workFor(workerData);
  parentPort.postMessage({result, elapsedMs:Math.max(1,Math.ceil(performance.now()-start))});
}
