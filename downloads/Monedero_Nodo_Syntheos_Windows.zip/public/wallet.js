import {mountPortalBridge} from './portal-bridge.js';

const el=id=>document.getElementById(id);
const label={minar:'Minería',enviar:'Envío',compartir:'Recursos compartidos',cobro:'Cobro por cómputo',
  PENDIENTE_DE_SIL:'Pendiente de SIL',RECHAZADO_POR_SIL:'Rechazado por SIL',ACEPTADO_EN_SIL:'Aceptado en SIL',
  CHECKPOINT_PILOTO:'Checkpoint de prueba',MYCELIAL:'CPU compartida de Mycelial',CPU_LOCAL:'CPU local',
  SIN_CONFIGURAR:'Sin configurar',NO_DISPONIBLE:'Sin conexión',REQUIERE_AUTORIZACION:'Requiere autorización',
  RESPUESTA_NO_RECONOCIDA:'Respuesta no reconocida',SOLO_LECTURA:'Conectado en lectura',
  CONECTADO:'Conectado',SOLO_LOCAL:'Solo local',SIN_RESPUESTA:'Sin respuesta',LISTO:'Listo',
  OFERTA_ACTIVA:'Oferta activa',EN_PAUSA:'Oferta en pausa',ERROR:'Error',ERROR_LOCAL:'Servicio local con error',
  ESCUCHANDO:'Servicio HTTPS escuchando'};
const errorText={saldo_disponible_insuficiente:'El saldo disponible no cubre ese envío.',
  destino_no_registrado:'La dirección de destino aún no existe en la SIL de prueba.',
  g0_requiere_fundador_y_chronos:'Se requiere el monedero fundador y Chronos disponibles.',
  limite_g0_del_piloto:'El primer fSYNT de prueba ya se generó.',
  gpu_no_verificada_para_compartir:'La prueba OpenCL de esta GPU no pasó. Su oferta sigue en pausa.',
  recibo_micelial_pendiente:'Mycelial aún no confirmó el recibo del trabajo.',
  local_resource_busy:'Este nodo ya ejecuta un trabajo de CPU. Intenta de nuevo cuando termine.'};
const assets={chronos:['SoftNFT Chronos','/art/chronos.webp'],licencia:['Licencia de producción','/art/licencia.webp']};
let state;
let busy=false;
let checking=false;
const format=new Intl.NumberFormat('es-BO',{maximumFractionDigits:6});

function item(primary,secondary,image){
  const li=document.createElement('li');
  if(image){
    const img=document.createElement('img');img.src=image;img.alt='';li.append(img);
  }
  const content=document.createElement('div');content.className='item';
  const line=document.createElement('div');line.textContent=primary;content.append(line);
  if(secondary){const detail=document.createElement('small');detail.textContent=secondary;content.append(detail);}
  li.append(content);return li;
}

function drawUsefulWork({summary,entries}){
  el('pouw-cost').textContent=summary.acceptedJobs?
    `${format.format(summary.computeCostFSynt)} fSYNT de prueba · ${summary.chronos} Chronos`:'Sin trabajos aceptados';
  const genesis=summary.genesis;
  el('pouw-genesis').textContent=genesis.fragments?
    `Emisión asociada ${genesis.fragments} fSYNT · ${genesis.attributedChronos} Chronos · ${format.format(genesis.attributedCostFSynt/genesis.fragments)} fSYNT de costo por fragmento`:
    'Sin emisión vinculada';
  const preview=summary.preview;
  const previewUnits=preview.pixels/preview.pixelsPerPreview;
  el('pouw-preview').textContent=previewUnits?
    `${format.format(previewUnits)} vistas equivalentes · ${preview.attributedChronos} Chronos · ${format.format(preview.attributedCostFSynt/previewUnits)} fSYNT de costo por vista equivalente`:
    'Sin vistas verificadas';
  el('pouw-pending').textContent=[
    summary.genesis.pendingJobs===1?'1 trabajo G0 sin emisión confirmada en este libro':
      summary.genesis.pendingJobs?`${summary.genesis.pendingJobs} trabajos G0 sin emisión confirmada en este libro`:'',
    summary.legacyJobs===1?'1 recibo anterior al registro PoUW':
      summary.legacyJobs?`${summary.legacyJobs} recibos anteriores al registro PoUW`:'',
  ].filter(Boolean).join(' · ');
  el('pouw-receipts').replaceChildren(...entries.map(work=>{
    const genesisJob=work.purpose==='G0_MANIFEST_CHECK';
    const result=genesisJob?(work.fragments?`${work.fragments} fSYNT asociado al asiento G0`:'Emisión pendiente de vincular'):
      `${format.format(work.pixels/preview.pixelsPerPreview)} vistas equivalentes verificadas`;
    const row=document.createElement('li');
    const details=document.createElement('details');
    const title=document.createElement('summary');
    title.textContent=`${genesisJob?'Validación G0':'Vista de Forge'} · ${work.costFSynt} fSYNT de prueba · ${result}`;
    const evidence=document.createElement('p');
    evidence.className='code';
    evidence.textContent=[
      `${work.profile} · ${work.elapsedMs} ms · ${work.chronos} Chronos · ${work.credited?'Cobro acreditado':'Cobro pendiente'}`,
      `Trabajo ${work.id} · Lote ${work.batch}`,
      `Hash de la prueba ${work.proofHash}`,
      `Hash del resultado ${work.outputSha256}`
    ].join('\n');
    details.append(title,evidence);
    row.append(details);
    return row;
  }));
}

function draw(){
  if(!state)return;
  const name=el('profile').value;
  const selected=state.profiles.find(profile=>profile.name===name);
  const other=state.profiles.find(profile=>profile.name!==name);
  el('balance').textContent=selected.balance+' fSYNT';
  el('address').textContent=selected.address;
  el('reserved').textContent=`${selected.available} disponibles${selected.available!==selected.balance?' · el resto está reservado para envíos pendientes':''}`;
  if(!el('recipient').value||el('recipient').dataset.autofill===el('recipient').value){
    el('recipient').value=other.address;el('recipient').dataset.autofill=other.address;
  }
  el('chronos').textContent=selected.chronos+' Chronos disponibles para el piloto';
  el('earnings').textContent=`${selected.earnings?.fragments??0} fSYNT acreditados por ${selected.earnings?.jobs??0} trabajos`+
    (selected.pendingRewards?` · ${selected.pendingRewards} fSYNT pendientes de SIL`:'');
  drawUsefulWork(selected.usefulWork);
  const locks=selected.locks.map(lock=>item(assets[lock.kind]?.[0]??'SoftNFT',lock.id,assets[lock.kind]?.[1]));
  el('locks').replaceChildren(...(locks.length?locks:[item('Sin SoftNFT bloqueados')]));
  el('sharing').textContent=`CPU del perfil ${selected.sharing?'ofrecida':'en pausa'} · GPU del nodo ${state.node.gpuShared?'ofrecida':'en pausa'}`;
  el('share').textContent=selected.sharing?'Pausar oferta de CPU':'Compartir CPU de prueba';
  el('share-gpu').textContent=state.node.gpuShared?'Pausar oferta de GPU':'Autorizar GPU de prueba';
  el('node-id').textContent=state.node.id;
  el('cpu').textContent=`${state.node.resources.logicalCPU} hilos lógicos disponibles`;
  el('ram').textContent=`${state.node.resources.ramAvailableMiB} MiB libres de ${state.node.resources.ramTotalMiB} MiB`;
  el('roles').replaceChildren(...state.node.roles.map(role=>item(`${role.name} · ${label[role.state]??role.state}`,roleDescription(role))));
  const records=[...selected.outbox].reverse().map(row=>item(label[row.action],
    [label[row.state],label[row.compute],errorText[row.error]??row.error].filter(Boolean).join(' · ')));
  records.push(...selected.records.map(row=>{
    const incoming=row.action==='enviar'&&row.recipient===selected.address;
    return item((incoming?'Recepción':label[row.action])+(row.units?` · ${row.units} fSYNT`:''),
      [label[row.state],label[row.compute]].filter(Boolean).join(' · '));
  }));
  el('records').replaceChildren(...(records.length?records:[item('Aún no hay operaciones')]));
  el('sil').checked=state.sil==='EN_LINEA';
  el('sil-state').textContent=el('sil').checked?'En línea':'Sin conexión';
  el('checkpoint-link').checked=state.symbiotic==='RECEPTOR_PILOTO_DISPONIBLE';
  el('checkpoint-state').textContent=el('checkpoint-link').checked?'Disponible':'Sin conexión';
  el('mine').disabled=busy||!selected.founder||selected.g0Mined||selected.records.some(row=>row.action==='minar')||
    selected.outbox.some(row=>row.action==='minar'&&row.state==='PENDIENTE_DE_SIL');
  for(const id of ['sync','share','share-gpu','sil','checkpoint-link'])el(id).disabled=busy;
  el('transfer').querySelector('button').disabled=busy||selected.available===0;
}

function roleDescription(role){
  const reply=role.response;
  if(role.name==='Coordinador')return `${reply.chronosDisponibles} Chronos del nodo · ${reply.chronosReservados} en reserva`;
  if(role.name==='Trabajador')return `CPU ${reply.cpu?'ofrecida':reply.cpuPruebaLocal?'ofrecida por perfil de prueba':'en pausa'} · GPU ${reply.gpu?'ofrecida':'en pausa'} · ${reply.redPrivada?'HTTPS activo':'solo local'}`;
  return `${reply.recibos} recibos guardados · ${reply.medio}`;
}

function linkDescription(name,link){
  if(link.status&&link.state==='ERROR')return `HTTP ${link.status}`;
  if(name==='Symbiotic')return link.response?.version?`HTTP ${link.status} · Symbiotic L1 ${link.response.version}`:
    link.status?`HTTP ${link.status}`:'Consulta directa a Symbiotic Main';
  if(name==='SIL')return link.response?.ok?`HTTP ${link.status} · libro piloto`:
    link.status?`HTTP ${link.status}`:'El libro local está sin respuesta';
  if(link.response?.id)return link.response.id+' · '+link.response.roles.map(role=>`${role.name} ${label[role.state]??role.state}`).join(' · ');
  const local=label[link.listener]??link.listener;
  return typeof link.response==='string'?`${local} · ${link.response}`:local;
}

async function observe(){
  if(checking)return;
  checking=true;el('probe').disabled=true;
  try {
    const reply=await fetch('/api/observacion');
    if(!reply.ok)throw new Error('observacion_no_disponible');
    const data=await reply.json();
    const cards=Object.entries(data.links).map(([name,link])=>item(`${name} · ${label[link.state]??link.state}`,
      [link.type,linkDescription(name,link)].filter(Boolean).join(' · ')));
    el('lines').replaceChildren(...cards);
    el('checked-at').textContent='Actualizado '+new Date(data.checkedAt).toLocaleTimeString('es');
    el('gpu').textContent=data.gpu.adaptadores.length?data.gpu.adaptadores
      .map(gpu=>`${gpu.nombre}${gpu.version_controlador?` · controlador ${gpu.version_controlador}`:''}`).join(' / '):data.gpu.estado;
    if(!busy){
      const current=await fetch('/api/state');
      if(current.ok&&!busy){state=await current.json();draw();}
    }
  } catch {el('checked-at').textContent='Observación no disponible';}
  finally {checking=false;el('probe').disabled=false;}
}

async function action(type,payload={}){
  if(busy)return;
  busy=true;
  draw();
  el('message').textContent='Procesando…';
  try {
    const response=await fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:el('profile').value,action:type,payload})});
    const result=await response.json();
    if(!response.ok)throw new Error(result.error);
    state=result;
    el('message').textContent='';
  } catch(error){ el('message').textContent=errorText[error.message]??'No se pudo completar la operación.'; }
  finally{busy=false;draw();void observe();}
}

el('profile').addEventListener('change',()=>{el('message').textContent='';draw();});
for(const button of document.querySelectorAll('[data-action]'))button.addEventListener('click',()=>action(button.dataset.action));
el('share').addEventListener('click',()=>action('compartir',{enabled:!state.profiles.find(p=>p.name===el('profile').value).sharing}));
el('share-gpu').addEventListener('click',()=>action('gpu-compartir',{enabled:!state.node.gpuShared}));
el('transfer').addEventListener('submit',event=>{
  event.preventDefault();
  action('enviar',{recipient:el('recipient').value.trim(),units:Number(el('amount').value)});
});
el('sil').addEventListener('change',event=>action('conexion-sil',{enabled:event.target.checked}));
el('checkpoint-link').addEventListener('change',event=>action('conexion-checkpoint',{enabled:event.target.checked}));
el('probe').addEventListener('click',observe);
mountPortalBridge({profile:el('profile'),open:el('pouw-open-portal'),download:el('pouw-export'),status:el('pouw-link-status')});

try {
  const response=await fetch('/api/state');
  if(!response.ok)throw new Error('wallet_unavailable');
  state=await response.json();draw();void observe();
  setInterval(()=>{if(!document.hidden&&!busy)void observe();},15000);
} catch { el('message').textContent='El proceso local del monedero no respondió.'; }
