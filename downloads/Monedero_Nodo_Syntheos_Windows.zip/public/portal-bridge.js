const PORTAL=new URL('https://headless-wnqvgvqzhmo-kventasint-140a.wix-site-host.com/pouw.html');

export function mountPortalBridge({profile, open, download, status}) {
  let finishPrevious=()=>{};
  const say=text=>{status.textContent=text;};
  async function report(name) {
    const response=await fetch('/api/pouw/report',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({profile:name}),signal:AbortSignal.timeout(5000)});
    if(!response.ok)throw new Error('informe_no_disponible');
    return response.json();
  }

  open.addEventListener('click',()=>{
    finishPrevious();
    const name=profile.value;
    const nonce=crypto.randomUUID();
    const target=new URL(PORTAL);
    target.hash=new URLSearchParams({pair:nonce,node:location.origin}).toString();
    const portal=window.open(target,'_blank');
    if(!portal){say('El navegador bloqueó la pestaña. Descarga el informe para importarlo en Syntheos.');return;}
    say('Esperando que Syntheos reciba el informe del perfil '+name+'…');
    let active=true, sent=false;
    const finish=()=>{
      active=false;
      window.removeEventListener('message',receive);
      clearTimeout(timeout);
    };
    finishPrevious=finish;
    const timeout=setTimeout(()=>{
      finish();
      say('La conexión no se completó. Vuelve a intentarla o descarga el informe firmado.');
    },20000);

    async function receive(event) {
      const {type, pair}=event.data??{};
      if(event.origin!==PORTAL.origin||event.source!==portal||pair!==nonce)return;
      if(type==='syntheos.pouw.loaded'&&sent){
        finish();
        say('Informe del perfil '+name+' verificado en Syntheos.');
      } else if(type==='syntheos.pouw.ready'&&!sent) {
        sent=true;
        try {
          const data=await report(name);
          if(active)portal.postMessage({type:'syntheos.pouw.report',pair:nonce,report:data},PORTAL.origin);
        } catch {
          if(!active)return;
          finish();
          say('No se pudo crear el informe. Vuelve a intentarlo.');
        }
      }
    }
    window.addEventListener('message',receive);
  });

  download.addEventListener('click',async()=>{
    const name=profile.value;
    download.disabled=true;
    try {
      const value=await report(name);
      const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));
      const link=document.createElement('a');
      link.href=url;
      link.download='syntheos-pouw-'+name+'.json';
      link.click();
      setTimeout(()=>URL.revokeObjectURL(url),1000);
      say('Importa el archivo en la sección PoUW de Syntheos.');
    } catch {
      say('No se pudo descargar el informe. Vuelve a intentarlo.');
    } finally {download.disabled=false;}
  });
}
