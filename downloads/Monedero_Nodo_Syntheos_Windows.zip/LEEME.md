# Monedero Nodo Syntheos v0.8

Extrae el paquete y abre `Abrir-Monedero-SIL.cmd` en Windows con Node.js 24. Se abrirá el panel en tu navegador. Si hace falta, usa la dirección que aparece en la consola. Conserva la consola abierta mientras trabajas. Para iniciar desde una terminal usa `node demo-server.mjs`.

El monedero crea y conserva su identidad Mycelial al arrancar. El coordinador, el trabajador y el almacenamiento funcionan bajo esa identidad. La actualización usa la misma carpeta de datos que la versión 0.7 y conserva los perfiles y sus operaciones. Los perfiles A y B sirven para probar tareas y transferencias dentro de una instalación.

## Lo que muestra el panel

| Sección | Datos |
| --- | --- |
| Mi nodo Mycelial | Identidad persistente, hilos de CPU, RAM libre y total, adaptadores de vídeo de Windows y versión del controlador. |
| Componentes integrados | El coordinador muestra Chronos y reservas. El trabajador muestra consentimiento y disponibilidad por recurso. El almacenamiento responde con el número de recibos conservados. |
| Vías de conexión | Symbiotic Main por HTTPS en lectura, SIL por HTTP local y el par Mycelial por HTTPS autenticado cuando está configurado. El panel indica el estado, el código HTTP cuando hubo respuesta y la hora de la observación. |
| Activos | SoftNFT bloqueados, Chronos de la cuenta y la representación de SYNT G0 preparada por Forge. |
| Cobros | fSYNT de prueba acreditados en SIL o pendientes durante una interrupción. |
| Proof of Useful Work | Tiempo, Chronos, costo de cómputo, resultado atribuible y hashes del trabajo aceptado. |

## Compartir y cobrar

La oferta de CPU y GPU empieza en pausa en una instalación nueva. En el perfil **A** puedes ofrecer CPU a la red o autorizar la GPU tras verificar OpenCL. El perfil **B** puede ofrecer CPU para la prueba local. El trabajador admite una tarea de CPU por instalación y usa la memoria del equipo. El panel observa RAM libre y total.

Los trabajos compartidos reservan **8 Chronos de prueba** del nodo. El coordinador verifica el resultado, descuenta los Chronos usados y conserva un recibo de **10 fSYNT de prueba**. El monedero los acredita en SIL una sola vez. Si SIL está interrumpida, el cobro queda pendiente hasta que vuelva. El saldo de Chronos de la cuenta G0 y el presupuesto de cómputo del nodo aparecen por separado.

El flujo G0 prueba un nodo Mycelial configurado, luego un perfil local que aporte y finalmente CPU local. Con `node Forge-Recursos.mjs render imagen.png` se prueba GPU compartida con Chronos, GPU local compatible y finalmente CPU. El panel del monedero visualiza los activos ya generados.

## Proof of Useful Work

El coordinador verifica el resultado y firma el recibo con el perfil, el tiempo declarado por el trabajador, los Chronos consumidos y los hashes de la prueba y del resultado. El costo de cómputo refleja el pago acordado en fSYNT de prueba. El valor de mercado y el costo eléctrico quedan fuera de esta medida.

- **G0.** El monedero cuenta el fragmento cuando este libro SIL confirma un asiento de emisión vinculado al recibo y al mismo resultado. Si el asiento está en otro libro, la emisión queda pendiente de vincular en esta instalación.
- **Forge.** Cada trabajo cuenta los píxeles de la porción que verificó. Dos mitades suman una vista equivalente. Dividir el costo aceptado de esas porciones por las vistas equivalentes da una referencia de costo por vista.
- **Recibos anteriores.** Conservan su cobro y aparecen como anteriores al desglose PoUW.

Para ver un ejemplo, activa **Compartir CPU de prueba** en **B · Receptor** y solicita **Minar 1 fSYNT de prueba** desde **A · Fundador G0**. Vuelve a B y abre **Proof of Useful Work**. Tras la confirmación local, el piloto atribuye a ese trabajo **1 fSYNT producido** y registra **10 fSYNT de costo de cómputo**. El mismo recibo solo se acredita una vez.

## Consultar PoUW en Syntheos en línea

En **Proof of Useful Work** elige el perfil y pulsa **Abrir en Syntheos en línea**. Se abre el portal oficial y se comparte un informe del perfil elegido firmado con la clave del nodo. El portal comprueba la firma en tu navegador. Para actualizar, vuelve a abrir el informe desde el monedero.

Si tu navegador bloquea la conexión entre pestañas, pulsa **Descargar informe firmado** e impórtalo en [PoUW de Syntheos](https://headless-wnqvgvqzhmo-kventasint-140a.wix-site-host.com/pouw.html). El visor lee los datos de prueba y los conserva mientras está abierta la página. Las claves privadas permanecen en el monedero.

## Conectar dos instalaciones en una red privada

Inicia el mismo monedero en los dos equipos. Cada uno genera su propia identidad. En PowerShell puedes establecer una variable con el formato `$env:SYNTHEOS_MYCELIAL_PORT = '8751'` antes de abrir el lanzador.

| Equipo | Ajuste |
| --- | --- |
| Proveedor | `SYNTHEOS_MYCELIAL_CERT` y `SYNTHEOS_MYCELIAL_KEY` apuntan a archivos PEM de un certificado confiable para el cliente. `SYNTHEOS_MYCELIAL_BIND` indica su dirección privada. La escucha predeterminada usa `127.0.0.1` y puerto 8751. |
| Ambos | `SYNTHEOS_MYCELIAL_TOKEN` contiene el mismo secreto, de 32 a 128 caracteres. Se admiten letras, números, guiones y guiones bajos. |
| Consumidor | `SYNTHEOS_MYCELIAL_PROOF_ORIGIN` indica el origen HTTPS del nodo proveedor y debe usar el nombre o IP de su certificado. Si usas una autoridad privada, establece `NODE_EXTRA_CA_CERTS` antes del arranque. |

El proveedor habilita CPU desde el perfil A. El consumidor comprueba **Mycelial** en Vías de conexión. Los tres componentes se activan automáticamente con el monedero. La consulta directa a Symbiotic Main usa `/healthz`. Puedes elegir otro origen HTTPS con `SYNTHEOS_SYMBIOTIC_ORIGIN`.

La instalación opera con un libro SIL y créditos de prueba. Dos instalaciones pueden cooperar por Mycelial. La liquidación y las transferencias entre libros SIL de producción, los anclajes a Symbiotic y la prueba en una GPU física siguen pendientes.
