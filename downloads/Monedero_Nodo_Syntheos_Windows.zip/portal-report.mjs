import {createPublicKey,sign} from 'node:crypto';
import {canonical} from './compute/resource-work.mjs';

export function createPortalReport(profile, node, usefulWork) {
  const key=node.pool('A').key('coordinator');
  const body={
    schema:'syntheos.pouw-portal/1', mode:'SIMULATION_ONLY',
    capturedAt:new Date().toISOString(), nodeId:node.id, profile, usefulWork,
    publicKey:createPublicKey(key.publicKey).export({type:'spki',format:'der'}).toString('base64'),
  };
  return {...body, signature:sign(null,Buffer.from(canonical(body)),key.privateKey).toString('base64')};
}
