import {execFile} from 'node:child_process';
import {win32} from 'node:path';
import {fileURLToPath} from 'node:url';
import {promisify} from 'node:util';
import {assertThat, HEIGHT, MAX_SHARDS, WIDTH, workFor} from './resource-work.mjs';

const run = promisify(execFile);

export async function renderGpu(ticket) {
  if (process.platform !== 'win32' || !process.env.SystemRoot) throw new Error('windows_opencl_unavailable');
  const {purpose, batch, index, count} = ticket;
  assertThat(purpose === 'FORGE_PREVIEW' && /^[a-f0-9]{32}$/.test(batch) &&
    Number.isInteger(count) && count >= 1 && count <= MAX_SHARDS &&
    Number.isInteger(index) && index >= 0 && index < count, 'unsupported_gpu_job');
  const y0 = Math.floor(index * HEIGHT / count);
  const rows = Math.floor((index + 1) * HEIGHT / count) - y0;
  const shift = parseInt(batch.slice(0, 4), 16) % 180;
  const executable = win32.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const script = fileURLToPath(new URL('./gpu/Measure-GpuShard.ps1', import.meta.url));
  const started = performance.now();
  const {stdout} = await run(executable, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script,
    '-FirstRow', String(y0), '-Rows', String(rows), '-Shift', String(shift)], {
    windowsHide: true, timeout: 7000, maxBuffer: 1024 * 1024,
  });
  const result = Buffer.from(stdout.trim(), 'base64');
  assertThat(result.length === WIDTH * rows * 3, 'invalid_gpu_result_length');
  return {result, elapsedMs: Math.min(8000, Math.max(1, Math.ceil(performance.now() - started)))};
}

export async function verifyGpu(render = renderGpu) {
  const sample = {purpose: 'FORGE_PREVIEW', batch: '2f'.repeat(16), index: 0, count: MAX_SHARDS};
  try {
    const {result} = await render(sample);
    return Buffer.from(result).equals(workFor(sample));
  } catch {
    return false;
  }
}
