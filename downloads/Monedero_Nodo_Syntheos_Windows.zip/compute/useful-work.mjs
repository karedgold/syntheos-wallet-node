import {assertThat as need,canonical,sha,WIDTH,HEIGHT,MAX_SHARDS} from './resource-work.mjs';

export const PREVIEW_PIXELS = WIDTH * HEIGHT;
const HASH = /^[a-f0-9]{64}$/;

export function usefulWork(ticket, proof) {
  return {
    protocol:'PoUW', version:1, purpose:ticket.purpose, profile:ticket.profile,
    index:ticket.index, count:ticket.count, elapsedMs:proof.elapsedMs, proofHash:sha(canonical(proof))
  };
}

export function validateUsefulWork(receipt, proof) {
  const work=receipt.work;
  if(work===undefined)return null;
  need(work?.protocol==='PoUW' && work.version===1 &&
    ['G0_MANIFEST_CHECK','FORGE_PREVIEW'].includes(work.purpose) &&
    (work.profile==='cpu-shared-pilot-v1' ||
      (work.profile==='opencl-preview-pilot-v1' && work.purpose==='FORGE_PREVIEW')) &&
    Number.isInteger(work.index) && Number.isInteger(work.count) &&
    work.index>=0 && work.index<work.count && work.count<=MAX_SHARDS &&
    Number.isInteger(work.elapsedMs) && work.elapsedMs>=1 && work.elapsedMs<=8000 &&
    receipt.consumedChronos===Math.ceil(work.elapsedMs/1000) &&
    receipt.releasedChronos===8-receipt.consumedChronos && HASH.test(work.proofHash),
    'invalid_useful_work');
  if(proof)need(work.elapsedMs===proof.elapsedMs && work.proofHash===sha(canonical(proof)),
    'useful_work_binding_mismatch');
  return work;
}

export function previewPixels(work) {
  return WIDTH * (Math.floor((work.index+1)*HEIGHT/work.count)-Math.floor(work.index*HEIGHT/work.count));
}
