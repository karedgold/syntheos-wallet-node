using System;
using System.Runtime.InteropServices;

[assembly: DefaultDllImportSearchPaths(DllImportSearchPath.System32)]

namespace Syntheos {
    public static class OpenClShard {
        private const string OpenCl = "OpenCL.dll";
        [DllImport(OpenCl)] private static extern int clGetPlatformIDs(uint count, [Out] IntPtr[] platforms, out uint found);
        [DllImport(OpenCl)] private static extern int clGetDeviceIDs(IntPtr platform, ulong type, uint count, [Out] IntPtr[] devices, out uint found);
        [DllImport(OpenCl)] private static extern IntPtr clCreateContext(IntPtr properties, uint count, IntPtr[] devices, IntPtr callback, IntPtr data, out int error);
        [DllImport(OpenCl)] private static extern IntPtr clCreateCommandQueue(IntPtr context, IntPtr device, ulong flags, out int error);
        [DllImport(OpenCl)] private static extern IntPtr clCreateProgramWithSource(IntPtr context, uint count, IntPtr[] source, UIntPtr[] lengths, out int error);
        [DllImport(OpenCl)] private static extern int clBuildProgram(IntPtr program, uint count, IntPtr[] devices, IntPtr flags, IntPtr callback, IntPtr data);
        [DllImport(OpenCl, ExactSpelling = true, CharSet = CharSet.Ansi)] private static extern IntPtr clCreateKernel(IntPtr program, string name, out int error);
        [DllImport(OpenCl)] private static extern IntPtr clCreateBuffer(IntPtr context, ulong flags, UIntPtr size, IntPtr host, out int error);
        [DllImport(OpenCl, EntryPoint = "clSetKernelArg")] private static extern int SetBuffer(IntPtr kernel, uint index, UIntPtr size, ref IntPtr value);
        [DllImport(OpenCl, EntryPoint = "clSetKernelArg")] private static extern int SetInt(IntPtr kernel, uint index, UIntPtr size, ref int value);
        [DllImport(OpenCl)] private static extern int clEnqueueNDRangeKernel(IntPtr queue, IntPtr kernel, uint dimensions, IntPtr offset, UIntPtr[] size, IntPtr local, uint waitCount, IntPtr wait, IntPtr signal);
        [DllImport(OpenCl)] private static extern int clEnqueueReadBuffer(IntPtr queue, IntPtr buffer, uint blocking, UIntPtr offset, UIntPtr size, [Out] byte[] output, uint waitCount, IntPtr wait, IntPtr signal);
        [DllImport(OpenCl)] private static extern int clReleaseMemObject(IntPtr buffer);
        [DllImport(OpenCl)] private static extern int clReleaseKernel(IntPtr kernel);
        [DllImport(OpenCl)] private static extern int clReleaseProgram(IntPtr program);
        [DllImport(OpenCl)] private static extern int clReleaseCommandQueue(IntPtr queue);
        [DllImport(OpenCl)] private static extern int clReleaseContext(IntPtr context);

        private static void Check(int error, string action) {
            if (error != 0) throw new InvalidOperationException(action + " (OpenCL " + error + ")");
        }

        public static byte[] Render(string source, int firstRow, int rows, int shift) {
            uint count;
            Check(clGetPlatformIDs(0, null, out count), "Enumerate platforms");
            IntPtr[] platforms = new IntPtr[count];
            Check(clGetPlatformIDs(count, platforms, out count), "Read platforms");
            foreach (IntPtr platform in platforms) {
                const ulong gpuDevice = 4;
                if (clGetDeviceIDs(platform, gpuDevice, 0, null, out count) != 0 || count == 0) continue;
                IntPtr[] devices = new IntPtr[count];
                if (clGetDeviceIDs(platform, gpuDevice, count, devices, out count) != 0) continue;
                foreach (IntPtr device in devices) {
                    try { return Dispatch(platform, device, source, firstRow, rows, shift); }
                    catch (InvalidOperationException) { }
                }
            }
            throw new InvalidOperationException("No working OpenCL GPU was found.");
        }

        private static byte[] Dispatch(IntPtr platform, IntPtr device, string source, int firstRow, int rows, int shift) {
            IntPtr none = IntPtr.Zero;
            IntPtr context = none, queue = none, program = none, kernel = none, buffer = none;
            IntPtr[] devices = new IntPtr[] { device };
            IntPtr code = Marshal.StringToHGlobalAnsi(source);
            IntPtr properties = Marshal.AllocHGlobal(3 * IntPtr.Size);
            int error;
            try {
                Marshal.WriteIntPtr(properties, 0, new IntPtr(0x1084));
                Marshal.WriteIntPtr(properties, IntPtr.Size, platform);
                Marshal.WriteIntPtr(properties, 2 * IntPtr.Size, none);
                context = clCreateContext(properties, 1, devices, none, none, out error);
                Check(error, "Create context");
                queue = clCreateCommandQueue(context, device, 0, out error);
                Check(error, "Create queue");
                program = clCreateProgramWithSource(context, 1, new IntPtr[] { code }, null, out error);
                Check(error, "Create program");
                Check(clBuildProgram(program, 1, devices, none, none, none), "Build preview kernel");
                kernel = clCreateKernel(program, "render_shard", out error);
                Check(error, "Create preview kernel");
                uint pixels = (uint)(rows * 640);
                byte[] output = new byte[pixels * 3];
                UIntPtr bytes = new UIntPtr(pixels * 3);
                buffer = clCreateBuffer(context, 2, bytes, none, out error);
                Check(error, "Create result buffer");
                Check(SetBuffer(kernel, 0, new UIntPtr((uint)IntPtr.Size), ref buffer), "Bind result buffer");
                Check(SetInt(kernel, 1, new UIntPtr(4u), ref firstRow), "Bind first row");
                Check(SetInt(kernel, 2, new UIntPtr(4u), ref shift), "Bind preview seed");
                Check(clEnqueueNDRangeKernel(queue, kernel, 1, none, new UIntPtr[] { new UIntPtr(pixels) }, none, 0, none, none), "Execute on GPU");
                Check(clEnqueueReadBuffer(queue, buffer, 1, UIntPtr.Zero, bytes, output, 0, none, none), "Read GPU result");
                return output;
            } finally {
                if (buffer != none) clReleaseMemObject(buffer);
                if (kernel != none) clReleaseKernel(kernel);
                if (program != none) clReleaseProgram(program);
                if (queue != none) clReleaseCommandQueue(queue);
                if (context != none) clReleaseContext(context);
                Marshal.FreeHGlobal(properties);
                Marshal.FreeHGlobal(code);
            }
        }
    }
}
