kernel void render_shard(global uchar *out, int y0, int shift) {
    int i = (int)get_global_id(0);
    int x = i % 640;
    int y = y0 + i / 640;
    int u = x - 320;
    int v = y - 180;
    int distance = 5 * (int)abs(u) + 3 * (int)abs(v);
    int ridge = max(0, 122 - (int)abs(distance - 445) * 3);
    int inner = max(0, 82 - distance / 6);
    int haze = max(0, 66 - (u*u + v*v) / 620);
    int ray = max(0, 18 - (int)abs((x + 2*y + shift) % 180 - 90));
    int glow = min(225, ridge + inner + haze + ray);
    out[3*i] = (uchar)(7 + 105*glow / 225);
    out[3*i + 1] = (uchar)(14 + 218*glow / 225);
    out[3*i + 2] = (uchar)(29 + 212*glow / 225);
}
