param(
    [Parameter(Mandatory = $true)][ValidateRange(0,359)][int]$FirstRow,
    [Parameter(Mandatory = $true)][ValidateRange(1,360)][int]$Rows,
    [Parameter(Mandatory = $true)][ValidateRange(0,179)][int]$Shift
)
$ErrorActionPreference = 'Stop'
if ($FirstRow + $Rows -gt 360) { throw 'Invalid preview dimensions.' }
Add-Type -Path (Join-Path $PSScriptRoot 'OpenClShard.cs')
$source = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'shard.cl') -Raw
$result = [Syntheos.OpenClShard]::Render($source, $FirstRow, $Rows, $Shift)
[Console]::WriteLine([Convert]::ToBase64String($result))
