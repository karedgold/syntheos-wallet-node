import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { deflateSync } from 'node:zlib';
import { isMainThread, parentPort, workerData } from 'node:worker_threads';

export const WIDTH = 640;
export const HEIGHT = 360;
export const MAX_SHARDS = 4;
export const FIRST_MANIFEST = '21d77954c39aed67d3898269d5e9fcfb3c085003cf8bb287d1cbd00a019b6305';
export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const canonical = value => Array.isArray(value)
  ? '[' + value.map(canonical).join(',') + ']'
  : value && typeof value === 'object'
    ? '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}'
    : JSON.stringify(value);

export function assertThat(condition, message) {
  if (!condition) throw new Error(message);
}

export function workFor(ticket) {
  const { purpose, batch, index, count } = ticket;
  assertThat(Number.isInteger(index) && Number.isInteger(count) && count >= 1 &&
    count <= MAX_SHARDS && index >= 0 && index < count && /^[a-f0-9]{32}$/.test(batch), 'invalid_work');
  if (purpose === 'G0_MANIFEST_CHECK') {
    const manifest = JSON.parse(readFileSync(new URL('first-fragment.json', import.meta.url)));
    const digest = sha(canonical(manifest));
    assertThat(digest === FIRST_MANIFEST && manifest.ordinal === '1' && manifest.quantity === '1', 'manifest_mismatch');
    let result = Buffer.from(['synt-g0-manifest-v1',batch,index,digest].join(':'));
    for (let round = 0; round < 25000; round++) result = createHash('sha256').update(result).digest();
    return result;
  }
  assertThat(purpose === 'FORGE_PREVIEW', 'unsupported_work');
  const y0 = Math.floor(index * HEIGHT / count), y1 = Math.floor((index + 1) * HEIGHT / count);
  const rgb = Buffer.alloc((y1-y0) * WIDTH * 3);
  const shift = parseInt(batch.slice(0, 4),16) % 180;
  let offset = 0;
  for (let y = y0; y < y1; y++) for (let x = 0; x < WIDTH; x++) {
    const u=x-WIDTH/2,v=y-HEIGHT/2;
    const distance=5*Math.abs(u)+3*Math.abs(v);
    const ridge=Math.max(0,122-Math.abs(distance-445)*3);
    const inner=Math.max(0,82-Math.floor(distance/6));
    const haze=Math.max(0,66-Math.floor((u*u+v*v)/620));
    const ray=Math.max(0,18-Math.abs((x+2*y+shift)%180-90));
    const glow=Math.min(225,ridge+inner+haze+ray);
    rgb[offset++] = 7+Math.floor(105*glow/225);
    rgb[offset++] = 14+Math.floor(218*glow/225);
    rgb[offset++] = 29+Math.floor(212*glow/225);
  }
  return rgb;
}

function chunk(type, data) {
  const body = Buffer.concat([Buffer.from(type),data]);
  let crc = 0xffffffff;
  for (const byte of body) {
    crc ^= byte;
    for (let b = 0; b < 8; b++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  const prefix = Buffer.alloc(4), suffix = Buffer.alloc(4);
  prefix.writeUInt32BE(data.length);
  suffix.writeUInt32BE((crc ^ 0xffffffff) >>> 0);
  return Buffer.concat([prefix,body,suffix]);
}

export function previewPng(tiles) {
  const image = Buffer.concat(tiles);
  assertThat(image.length === WIDTH*HEIGHT*3, 'missing_preview_tiles');
  const header = Buffer.alloc(13), lines = Buffer.alloc((WIDTH*3+1)*HEIGHT);
  header.writeUInt32BE(WIDTH);
  header.writeUInt32BE(HEIGHT,4);
  header[8]=8; header[9]=2;
  for (let y = 0; y < HEIGHT; y++) image.copy(lines,y*(WIDTH*3+1)+1,y*WIDTH*3,(y+1)*WIDTH*3);
  return Buffer.concat([Buffer.from('89504e470d0a1a0a','hex'),chunk('IHDR',header),
    chunk('IDAT',deflateSync(lines)),chunk('IEND',Buffer.alloc(0))]);
}

if (!isMainThread) {
  const start = performance.now();
  const result = workFor(workerData);
  parentPort.postMessage({result, elapsedMs:Math.max(1,Math.ceil(performance.now()-start))});
}
