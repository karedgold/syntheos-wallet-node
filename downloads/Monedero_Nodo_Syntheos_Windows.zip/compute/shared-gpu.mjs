import {randomBytes, timingSafeEqual} from 'node:crypto';
import {createServer} from 'node:https';
import {readFileSync} from 'node:fs';
import {GPU_PROFILE, SLOT} from './resource-pool.mjs';
import {renderGpu, verifyGpu} from './gpu-render.mjs';
import {assertThat, previewPng, sha, workFor} from './resource-work.mjs';

const MODE = 'SIMULATION_ONLY';
const ID = /^[a-f0-9]{32}$/;
const TOKEN = /^[A-Za-z0-9_-]{32,128}$/;

function send(response, status, payload) {
  response.writeHead(status, {'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store'});
  response.end(JSON.stringify(payload));
}

export function sharedGpuHandler({provider, token, gpu = renderGpu}) {
  assertThat(TOKEN.test(token ?? ''), 'invalid_shared_gpu_token');
  const credential = Buffer.from('Bearer ' + token);
  let active = false;
  return async (request, response) => {
    const supplied = Buffer.from(request.headers.authorization ?? '');
    if (supplied.length !== credential.length || !timingSafeEqual(supplied, credential)) {
      return send(response, 401, {error: 'unauthorized'});
    }
    if (request.method !== 'GET' && request.method !== 'POST') return send(response, 405, {error: 'method'});
    if (request.url !== '/v1/gpu' && !/^\/v1\/gpu\/[a-f0-9]{32}$/.test(request.url)) {
      return send(response, 404, {error: 'not_found'});
    }
    let batch;
    let reserved = false;
    let ownsSlot = false;
    let settled = false;
    try {
      if (request.url === '/v1/gpu' && request.method === 'GET') {
        const status = provider.status();
        return send(response, 200, {
          mode: MODE, profile: GPU_PROFILE, available: !active && status.host.sharesGpu && status.availableChronos >= SLOT,
        });
      }
      if (request.url === '/v1/gpu') return send(response, 405, {error: 'method'});
      batch = request.url.slice('/v1/gpu/'.length);
      const previous = provider.gpuReceipt(batch);
      if (previous) return send(response, 200, {mode: MODE, ...previous});
      if (request.method === 'GET') return send(response, 404, {error: 'receipt_unavailable'});
      if (request.headers['transfer-encoding'] || Number(request.headers['content-length'] ?? 0) !== 0) {
        return send(response, 400, {error: 'body_not_supported'});
      }
      if (active) return send(response, 429, {error: 'gpu_busy'});
      active = ownsSlot = true;
      const offer = provider.workerOffer(GPU_PROFILE);
      provider.addWorker(offer);
      const {tickets} = provider.reserve('FORGE_PREVIEW', [offer.id], batch);
      reserved = true;
      const proof = await provider.contribute(tickets[0], gpu);
      const receipt = provider.settle(proof);
      settled = true;
      provider.collect(receipt);
      return send(response, 200, {mode: MODE, proof, receipt});
    } catch (error) {
      if (settled) return send(response, 500, {error: 'gpu_provider_error'});
      if (reserved) {
        try { provider.cancel(batch); }
        catch { return send(response, 500, {error: 'gpu_provider_error'}); }
      }
      const canFallBack = new Set(['insufficient_chronos', 'worker_must_opt_in', 'worker_opt_in_withdrawn',
        'worker_already_reserved', 'reservation_closed', 'local_resource_busy']);
      if (!reserved && !canFallBack.has(error.message)) return send(response, 500, {error: 'gpu_provider_error'});
      return send(response, 409, {error: canFallBack.has(error.message) ? error.message : 'gpu_work_released'});
    } finally {
      if (ownsSlot) active = false;
    }
  };
}

export function startSharedGpu(provider, env = process.env) {
  assertThat(env.SYNTHEOS_GPU_TLS_CERT && env.SYNTHEOS_GPU_TLS_KEY, 'tls_certificate_and_key_required');
  const port = Number(env.SYNTHEOS_GPU_PORT ?? 8443);
  assertThat(Number.isInteger(port) && port >= 1024 && port <= 65535, 'invalid_gpu_port');
  const handler = sharedGpuHandler({provider, token: env.SYNTHEOS_GPU_TOKEN});
  const server = createServer({cert: readFileSync(env.SYNTHEOS_GPU_TLS_CERT),
    key: readFileSync(env.SYNTHEOS_GPU_TLS_KEY), minVersion: 'TLSv1.2', headersTimeout: 5000,
    requestTimeout: 10000, keepAliveTimeout: 3000}, handler);
  server.listen(port, env.SYNTHEOS_GPU_BIND ?? '127.0.0.1');
  return server;
}

export function configuredProviders(env = process.env) {
  const entries = (env.SYNTHEOS_GPU_URLS ?? '').split(',').map(x => x.trim()).filter(Boolean);
  return [...new Set(entries)].map(entry => {
    const url = new URL(entry);
    assertThat(url.protocol === 'https:' && !url.username && !url.password && url.pathname === '/' &&
      !url.search && !url.hash, 'invalid_shared_gpu_url');
    return url.origin;
  });
}

function validatedTile(payload, expected, batch) {
  const {mode, proof, receipt} = payload;
  assertThat(mode === MODE && proof?.batch === batch && receipt?.batch === batch &&
    proof.id === receipt.id && proof.worker === receipt.worker && receipt.mode === MODE &&
    receipt.outputSha256 === proof.outputSha256, 'invalid_shared_gpu_receipt');
  assertThat(typeof proof.tile === 'string' && proof.tile.length === Math.ceil(expected.length / 3) * 4,
    'invalid_shared_gpu_tile');
  const tile = Buffer.from(proof.tile, 'base64');
  assertThat(tile.equals(expected) && sha(tile) === receipt.outputSha256, 'invalid_shared_gpu_tile');
  return tile;
}

async function readReply(response, maximumBytes = 1024*1024) {
  const data=[];
  let total=0;
  for await(const part of response.body){
    total+=part.length;
    assertThat(total<=maximumBytes, 'shared_gpu_response_too_large');
    data.push(part);
  }
  return JSON.parse(Buffer.concat(data).toString('utf8'));
}

export async function recoverSharedRender({providers, token, batch, fetcher = fetch}) {
  assertThat(ID.test(batch), 'invalid_batch');
  assertThat(providers.length && TOKEN.test(token ?? ''), 'shared_gpu_providers_and_token_required');
  const expected = workFor({purpose:'FORGE_PREVIEW', batch, count:1,index:0});
  for(const endpoint of providers){
    try {
      const response=await fetcher(endpoint+'/v1/gpu/'+batch,{headers:{Authorization:'Bearer '+token},
        redirect:'error',signal:AbortSignal.timeout(4000)});
      if(!response.ok)continue;
      const payload=await readReply(response);
      return {source:'gpu_compartida',batch,receipt:payload.receipt,png:previewPng([validatedTile(payload,expected,batch)])};
    } catch { /* A different authorized provider may hold the receipt. */ }
  }
  throw new Error('recibo_gpu_no_disponible_'+batch);
}

export async function renderPreferred({providers = [], token, fetcher = fetch, gpu = renderGpu,
  batch = randomBytes(16).toString('hex')} = {}) {
  assertThat(ID.test(batch), 'invalid_batch');
  if (providers.length) assertThat(TOKEN.test(token ?? ''), 'invalid_shared_gpu_token');
  const ticket = {purpose: 'FORGE_PREVIEW', batch, count: 1, index: 0};
  const settings = timeout => ({headers: {Authorization: 'Bearer ' + token},
    redirect: 'error', signal: AbortSignal.timeout(timeout)});
  for (const endpoint of providers) {
    let status;
    try {
      const response = await fetcher(endpoint + '/v1/gpu', settings(2500));
      if (response.ok) status = await readReply(response, 4096);
    } catch { continue; }
    if (status?.mode !== MODE || status.profile !== GPU_PROFILE || !status.available) continue;
    try {
      const response = await fetcher(endpoint + '/v1/gpu/' + batch, {...settings(12000), method: 'POST'});
      if (response.status === 409 || response.status === 429) continue;
      assertThat(response.ok, 'shared_gpu_request_failed');
      const payload = await readReply(response);
      const tile = validatedTile(payload, workFor(ticket), batch);
      return {source: 'gpu_compartida', batch, receipt: payload.receipt, png: previewPng([tile])};
    } catch {
      throw new Error('liquidacion_remota_sin_confirmar_' + batch);
    }
  }
  let expected;
  try {
    const {result} = await gpu(ticket);
    const tile = Buffer.from(result);
    expected = workFor(ticket);
    if (tile.equals(expected)) return {source: 'gpu_local', batch, png: previewPng([tile])};
  } catch { /* A local GPU is optional. */ }
  return {source: 'cpu_local', batch, png: previewPng([expected ?? workFor(ticket)])};
}

export async function enrollSharedGpu(provider, gpu = renderGpu) {
  assertThat(await verifyGpu(gpu), 'gpu_no_verificada_para_compartir');
  provider.trustManager(provider.coordinator());
  return provider.offerGpu(true);
}
