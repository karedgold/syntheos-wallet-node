import {createPublicKey,generateKeyPairSync,randomBytes,sign,verify} from 'node:crypto';
import {mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {availableParallelism,totalmem} from 'node:os';
import {DatabaseSync} from 'node:sqlite';
import {Worker} from 'node:worker_threads';
import {assertThat as need,canonical,sha,workFor,previewPng,MAX_SHARDS} from './resource-work.mjs';
import {renderGpu} from './gpu-render.mjs';
import {usefulWork,validateUsefulWork} from './useful-work.mjs';

export const SLOT = 8;
export const REWARD = 10;
const MODE='SIMULATION_ONLY';
const PROFILE='cpu-shared-pilot-v1';
export const GPU_PROFILE='opencl-preview-pilot-v1';
const PURPOSE=new Set(['G0_MANIFEST_CHECK','FORGE_PREVIEW']);
const ID=/^[a-f0-9]{32}$/;
const rnd=()=>randomBytes(16).toString('hex');
const empty=()=>({credits:0,spent:0,rewardFSynt:0,workers:{},batches:{}});

function signed(body,key) {
  return {...body,signature:sign(null,Buffer.from(canonical(body)),key).toString('base64')};
}
function publicKey(pem) {
  need(typeof pem==='string' && pem.length<=160,'invalid_public_key');
  const key=createPublicKey(pem);
  need(key.asymmetricKeyType==='ed25519','invalid_key_algorithm');
  return key;
}
function readSigned(record,pem) {
  const {signature,...body}=record;
  need(typeof signature==='string' && /^[A-Za-z0-9+/]{86}==$/.test(signature),'invalid_signature_format');
  need(verify(null,Buffer.from(canonical(body)),publicKey(pem),Buffer.from(signature,'base64')),'invalid_signature');
  return body;
}
function summary(state) {
  const reserved=Object.values(state.batches).flatMap(b=>b.rows)
    .filter(x=>x.state==='reserved').reduce((n,x)=>n+x.ticket.chronos,0);
  need(state.credits-state.spent-reserved>=0,'chronos_accounting_error');
  return {mode:MODE,availableChronos:state.credits-state.spent-reserved,reservedChronos:reserved,
    consumedChronos:state.spent,rewardFSynt:state.rewardFSynt,noTokenIssued:true};
}

export class ResourceNode {
  constructor(home) {
    mkdirSync(home,{recursive:true,mode:0o700});
    this.db=new DatabaseSync(join(home,'resource-pool.sqlite'));
    this.db.exec('PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);');
  }
  close() { this.db.close(); }
  get(key,fallback) {
    const row=this.db.prepare('SELECT value FROM kv WHERE key=?').get(key);
    return row?JSON.parse(row.value):fallback;
  }
  set(key,value) {
    this.db.prepare('INSERT INTO kv VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
      .run(key,JSON.stringify(value));
  }
  transaction(action) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const result=action(); this.db.exec('COMMIT'); return result; }
    catch(error){ this.db.exec('ROLLBACK'); throw error; }
  }
  key(role) {
    return this.transaction(()=>{
      const prior=this.get(role+'-key',null);
      if(prior)return prior;
      const keys=generateKeyPairSync('ed25519',{
        publicKeyEncoding:{type:'spki',format:'pem'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
      const identity={...keys,id:sha(keys.publicKey).slice(0,32)};
      this.set(role+'-key',identity);
      return identity;
    });
  }
  coordinator() {
    const {id,publicKey}=this.key('coordinator');
    return {schema:'syntheos.resource-coordinator/1',mode:MODE,id,publicKey};
  }
  trustManager(record) {
    need(record?.schema==='syntheos.resource-coordinator/1' && record.mode===MODE,'invalid_coordinator');
    publicKey(record.publicKey);
    need(record.id===sha(record.publicKey).slice(0,32),'invalid_coordinator');
    this.set('trusted_manager',{id:record.id,publicKey:record.publicKey});
    return {trusted:record.id,mode:MODE};
  }
  offerCpu(enabled) {
    need(typeof enabled==='boolean','invalid_opt_in');
    this.set('offers_cpu',enabled);
    return {offersCpu:enabled,profile:PROFILE,threadsPerJob:1,maximumTaskMs:8000};
  }
  offerGpu(enabled) {
    need(typeof enabled==='boolean','invalid_opt_in');
    this.set('offers_gpu',enabled);
    return {offersGpu:enabled,profile:GPU_PROFILE,maximumTaskMs:8000};
  }
  workerOffer(profile=PROFILE) {
    need(profile===PROFILE || profile===GPU_PROFILE,'invalid_worker_profile');
    need(this.get(profile===GPU_PROFILE?'offers_gpu':'offers_cpu',false),'worker_must_opt_in');
    const key=this.key(profile===GPU_PROFILE?'gpu-worker':'worker');
    return signed({schema:'syntheos.cpu-offer/1',mode:MODE,role:'worker',id:key.id,
      publicKey:key.publicKey,profile,cores:1,expiresAt:Date.now()+24*3600000},key.privateKey);
  }
  update(action) {
    return this.transaction(()=>{
      const state=this.get('pool',empty());
      for(const batch of Object.values(state.batches))for(const row of batch.rows){
        if(row.state==='reserved'&&row.ticket.expiresAt<=Date.now())row.state='expired';
      }
      const result=action(state);
      this.set('pool',state);
      return result;
    });
  }
  addWorker(offer) {
    const body=readSigned(offer,offer?.publicKey);
    need(body.schema==='syntheos.cpu-offer/1' && body.mode===MODE && body.role==='worker' &&
      body.cores===1 && (body.profile===PROFILE || body.profile===GPU_PROFILE) && body.id===sha(body.publicKey).slice(0,32) &&
      Number.isSafeInteger(body.expiresAt) && body.expiresAt>Date.now() && body.expiresAt<=Date.now()+24*3600000,'invalid_offer');
    return this.update(state=>{state.workers[body.id]=body;return {acceptedWorker:body.id,cores:1};});
  }
  allocateDemoChronos(units) {
    need(Number.isSafeInteger(units)&&units>0&&units<=128,'invalid_demo_chronos');
    return this.update(state=>{need(state.credits===0,'demo_chronos_already_initialized');state.credits=units;return summary(state);});
  }
  status() {
    const host={logicalCPUs:availableParallelism(),ramMiB:Math.floor(totalmem()/1048576),
      sharesCpu:this.get('offers_cpu',false),sharesGpu:this.get('offers_gpu',false),threadsPerJob:1,profile:PROFILE};
    return this.update(state=>({...summary(state),host,workers:Object.keys(state.workers)}));
  }
  reserve(purpose,workers,batch=rnd()) {
    need(PURPOSE.has(purpose) && Array.isArray(workers) && workers.every(id=>typeof id==='string'&&ID.test(id)) &&
      new Set(workers).size===workers.length && workers.length>=1 && workers.length<=MAX_SHARDS,'invalid_worker_selection');
    need(typeof batch==='string' && ID.test(batch),'invalid_batch');
    const key=this.key('coordinator');
    return this.update(state=>{
      const existing=state.batches[batch];
      if(existing){
        const tickets=existing.rows.map(row=>row.ticket);
        need(existing.purpose===purpose && canonical(tickets.map(ticket=>ticket.worker))===canonical(workers),'batch_conflict');
        need(existing.rows.every(row=>row.state==='reserved'||row.state==='accepted'),'reservation_closed');
        return {batch,tickets,reservedChronos:existing.rows.filter(row=>row.state==='reserved').length*SLOT};
      }
      need(summary(state).availableChronos>=workers.length*SLOT,'insufficient_chronos');
      const issuedAt=Date.now();
      const tickets=workers.map((worker,index)=>{
        need(state.workers[worker]?.expiresAt>issuedAt,'worker_offer_unavailable');
        const {profile}=state.workers[worker];
        need(profile===PROFILE || purpose==='FORGE_PREVIEW','unsupported_gpu_job');
        need(!Object.values(state.batches).some(b=>b.rows.some(x=>x.state==='reserved'&&x.ticket.worker===worker)),
          'worker_already_reserved');
        return signed({schema:'syntheos.chronos-job/1',mode:MODE,id:rnd(),batch,purpose,index,
          count:workers.length,coordinator:key.id,worker,profile,chronos:SLOT,
          issuedAt,expiresAt:issuedAt+10*60000},key.privateKey);
      });
      state.batches[batch]={purpose,rows:tickets.map(ticket=>({ticket,state:'reserved'}))};
      return {batch,tickets,reservedChronos:tickets.length*SLOT};
    });
  }
  claimResource(lease,check=()=>{}) {
    const runId=rnd();
    this.transaction(()=>{
      check();
      need((this.get(lease,null)?.expiresAt??0)<=Date.now(),'local_resource_busy');
      this.set(lease,{id:runId,expiresAt:Date.now()+10000});
    });
    return runId;
  }
  releaseResource(lease,runId) {
    this.transaction(()=>{if(this.get(lease,null)?.id===runId)this.set(lease,null);});
  }
  async renderLocalGpu(ticket) {
    const lease='gpu_lease';
    const runId=this.claimResource(lease);
    try { return await renderGpu(ticket); }
    finally { this.releaseResource(lease,runId); }
  }
  async contribute(ticket, gpu=renderGpu) {
    const manager=this.get('trusted_manager',null);
    need(manager,'coordinator_not_trusted');
    const job=readSigned(ticket,manager.publicKey);
    const usesGpu=job.profile===GPU_PROFILE;
    const node=this.key(usesGpu?'gpu-worker':'worker');
    need(job.profile===PROFILE || (usesGpu && job.purpose==='FORGE_PREVIEW'),'unsupported_gpu_job');
    const consent=usesGpu?'offers_gpu':'offers_cpu';
    const lease=usesGpu?'gpu_lease':'cpu_lease';
    need(this.get(consent,false),'worker_must_opt_in');
    need(job.schema==='syntheos.chronos-job/1' && job.mode===MODE && job.worker===node.id &&
      job.coordinator===manager.id && job.chronos===SLOT &&
      PURPOSE.has(job.purpose) && typeof job.id==='string' && ID.test(job.id) && Number.isSafeInteger(job.issuedAt) &&
      job.issuedAt<=Date.now()+30000 && job.expiresAt===job.issuedAt+10*60000 && job.expiresAt>Date.now(),
    'invalid_or_expired_lease');
    const ticketHash=sha(canonical(ticket));
    const localKey='receipt:'+job.id;
    const prior=this.get(localKey,null);
    if(prior){need(prior.ticketHash===ticketHash,'worker_replay_conflict');return prior;}
    const runId=this.claimResource(lease,()=>need(this.get(consent,false),'worker_must_opt_in'));
    try {
      const {result,elapsedMs}=await (usesGpu?gpu(job):executeBounded(job));
      const bytes=Buffer.from(result);
      const proof=signed({schema:'syntheos.compute-proof/1',mode:MODE,id:job.id,batch:job.batch,
        worker:node.id,ticketHash,elapsedMs,outputSha256:sha(bytes),
        tile:job.purpose==='FORGE_PREVIEW'?bytes.toString('base64'):null},node.privateKey);
      return this.transaction(()=>{
        const saved=this.get(localKey,null);
        if(saved){need(saved.ticketHash===ticketHash,'worker_replay_conflict');return saved;}
        need(this.get(lease,null)?.id===runId,'local_resource_lease_lost');
        need(this.get(consent,false),'worker_opt_in_withdrawn');
        this.set(localKey,proof);
        return proof;
      });
    } finally {
      this.releaseResource(lease,runId);
    }
  }
  settle(proof) {
    need(typeof proof?.batch==='string' && ID.test(proof.batch) &&
      typeof proof.id==='string' && ID.test(proof.id),'unknown_work');
    const manager=this.key('coordinator');
    return this.update(state=>{
      const row=state.batches[proof.batch]?.rows.find(r=>r.ticket.id===proof.id);
      need(row,'unknown_work');
      const ticket=row.ticket;
      const body=readSigned(proof,state.workers[ticket.worker]?.publicKey);
      need(body.schema==='syntheos.compute-proof/1' && body.mode===MODE && body.worker===ticket.worker &&
        body.batch===ticket.batch && body.ticketHash===sha(canonical(ticket)),'receipt_binding_mismatch');
      const proofHash=sha(canonical(proof));
      if(row.state==='accepted'){need(row.proofHash===proofHash,'conflicting_result');return row.settlement;}
      need(row.state==='reserved' && Date.now()<ticket.expiresAt,'reservation_closed');
      need(Number.isSafeInteger(body.elapsedMs) && body.elapsedMs>=1 && body.elapsedMs<=8000,'invalid_execution_time');
      const recomputed=workFor(ticket);
      need(sha(recomputed)===body.outputSha256,'result_verification_failed');
      need(ticket.purpose==='FORGE_PREVIEW'?recomputed.toString('base64')===body.tile:body.tile===null,'invalid_result_payload');
      const consumed=Math.ceil(body.elapsedMs/1000);
      const settlement=signed({schema:'syntheos.compute-settlement/1',mode:MODE,batch:ticket.batch,id:ticket.id,worker:ticket.worker,
        consumedChronos:consumed,releasedChronos:ticket.chronos-consumed,rewardFSynt:REWARD,outputSha256:body.outputSha256,
        work:usefulWork(ticket,proof)},manager.privateKey);
      state.spent+=consumed;
      state.rewardFSynt+=REWARD;
      Object.assign(row,{state:'accepted',proofHash,settlement});
      return settlement;
    });
  }
  collect(settlement) {
    const manager=this.get('trusted_manager',null);
    need(manager,'coordinator_not_trusted');
    const result=readSigned(settlement,manager.publicKey);
    need(result.schema==='syntheos.compute-settlement/1' && result.mode===MODE &&
      typeof result.id==='string' && ID.test(result.id) && result.rewardFSynt===REWARD,'unexpected_settlement');
    const proof=this.get('receipt:'+result.id,null);
    need(proof && proof.worker===result.worker && proof.batch===result.batch &&
      proof.outputSha256===result.outputSha256,'settlement_binding_mismatch');
    validateUsefulWork(result,proof);
    return this.transaction(()=>{
      const key='reward:'+result.id;
      const existing=this.get(key,null);
      if(existing){need(canonical(existing)===canonical(settlement),'settlement_conflict');return existing;}
      this.set(key,settlement);
      return settlement;
    });
  }
  earnings() {
    const records=this.rewardReceipts();
    const rewardFSynt=records.reduce((total,r)=>total+r.rewardFSynt,0);
    return {mode:MODE,rewardFSynt,acceptedJobs:records.length,noTokenIssued:true};
  }
  rewardReceipts() {
    return this.db.prepare("SELECT value FROM kv WHERE key LIKE 'reward:%' ORDER BY rowid").all()
      .map(row=>JSON.parse(row.value));
  }
  recoverLocalRewards() {
    const state=this.get('pool',empty());
    for(const batch of Object.values(state.batches))for(const row of batch.rows){
      const id=row.ticket.id;
      if(row.state==='accepted'&&this.get('receipt:'+id,null)&&!this.get('reward:'+id,null))this.collect(row.settlement);
    }
  }
  cpuReceipt(batchId) {
    return this.completedReceipt(batchId,PROFILE);
  }
  gpuReceipt(batchId) {
    return this.completedReceipt(batchId,GPU_PROFILE);
  }
  completedReceipt(batchId,profile) {
    need(typeof batchId==='string' && ID.test(batchId),'invalid_batch');
    const batch=this.get('pool',empty()).batches[batchId];
    const row=batch?.rows[0];
    if(batch?.rows.length!==1 || row.ticket.profile!==profile || row.state!=='accepted')return null;
    const proof=this.get('receipt:'+row.ticket.id,null);
    need(proof,'settled_gpu_proof_missing');
    this.collect(row.settlement);
    return {proof,receipt:row.settlement};
  }
  cancel(batchId) {
    need(typeof batchId==='string' && ID.test(batchId),'unknown_batch');
    return this.update(state=>{
      const batch=state.batches[batchId];
      need(batch,'unknown_batch');
      let released=0;
      for(const row of batch.rows)if(row.state==='reserved'){row.state='cancelled';released+=row.ticket.chronos;}
      return {mode:MODE,batch:batchId,releasedChronos:released};
    });
  }
  exportPreview(batchId) {
    need(typeof batchId==='string' && ID.test(batchId),'unknown_batch');
    const batch=this.get('pool',empty()).batches[batchId];
    need(batch?.purpose==='FORGE_PREVIEW' && batch.rows.every(row=>row.state==='accepted'),'preview_incomplete');
    return previewPng(batch.rows.map(row=>workFor(row.ticket)));
  }
}

function executeBounded(task) {
  return new Promise((resolve,reject)=>{
    const thread=new Worker(new URL('resource-work.mjs',import.meta.url),{workerData:task,execArgv:[],
      resourceLimits:{maxOldGenerationSizeMb:24,maxYoungGenerationSizeMb:8,stackSizeMb:2}});
    const stop=()=>{clearTimeout(timeout);void thread.terminate();};
    const timeout=setTimeout(()=>{stop();reject(new Error('worker_timeout'));},8000);
    thread.once('message',value=>{stop();resolve(value);});
    thread.once('error',error=>{stop();reject(error);});
    thread.once('exit',code=>{clearTimeout(timeout);if(code!==0)reject(new Error('worker_exited'));});
  });
}
