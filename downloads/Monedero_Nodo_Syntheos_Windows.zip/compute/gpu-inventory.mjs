import {execFile, execFileSync} from 'node:child_process';
import {win32} from 'node:path';
import {promisify} from 'node:util';

const query = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$adapters = @(Get-CimInstance -ClassName Win32_VideoController -Property Name,DriverVersion,ConfigManagerErrorCode |
    Select-Object Name,DriverVersion,ConfigManagerErrorCode)
ConvertTo-Json -InputObject $adapters -Compress
`;

function argumentsForWindows() {
  const executable = win32.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  const command = Buffer.from(query, 'utf16le').toString('base64');
  return [executable, ['-NoProfile', '-NonInteractive', '-EncodedCommand', command], {
    encoding: 'utf8',
    timeout: 8000,
    maxBuffer: 131072,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  }];
}

function queryWindows() {return execFileSync(...argumentsForWindows());}

export async function readGpuInventoryAsync() {
  if(process.platform!=='win32')return readGpuInventory();
  try {
    const [file,args,options]=argumentsForWindows();
    const {stdout}=await promisify(execFile)(file,args,options);
    return readGpuInventory('win32',()=>stdout);
  } catch {
    return readGpuInventory('win32',()=>null);
  }
}

export function readGpuInventory(platform = process.platform, run = queryWindows) {
  const result = {aceleracion_gpu: 'no habilitada en el piloto', adaptadores: []};
  if (platform !== 'win32') return {...result, estado: 'consulta disponible en Windows'};

  try {
    const adapters = JSON.parse(run().replace(/^\uFEFF/, ''));
    if (!Array.isArray(adapters) || adapters.some(adapter => !adapter || typeof adapter.Name !== 'string' || !adapter.Name.trim())) {
      return {...result, estado: 'inventario de Windows no disponible'};
    }
    return {
      ...result,
      estado: adapters.length ? 'adaptadores informados por Windows' : 'Windows no informo adaptadores de video',
      adaptadores: adapters.map(adapter => ({
        nombre: adapter.Name.trim(),
        version_controlador: adapter.DriverVersion || null,
        codigo_dispositivo_windows: Number.isInteger(adapter.ConfigManagerErrorCode) ? adapter.ConfigManagerErrorCode : null,
      })),
    };
  } catch {
    return {...result, estado: 'inventario de Windows no disponible'};
  }
}
