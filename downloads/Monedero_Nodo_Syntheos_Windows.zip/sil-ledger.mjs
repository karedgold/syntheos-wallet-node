import {createPublicKey, generateKeyPairSync, randomBytes, sign, verify} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {canonical, sha, workFor} from './resource-work.mjs';
import {validateUsefulWork,previewPixels,PREVIEW_PIXELS} from './compute/useful-work.mjs';

export const NETWORK = 'syntheos-sil-wallet-pilot-1';
export const MODE = 'SIMULATION_ONLY';
export const GENESIS_LIMIT = 1;
const ROOT = '0'.repeat(64);
const ID = /^[a-f0-9]{32}$/;
const HASH = /^[a-f0-9]{64}$/;
const WALLET = /^synw_[a-f0-9]{32}$/;
const computeEntryId = id => sha('syntheos.pilot.compute:'+id).slice(0,32);
export const requestId = () => randomBytes(16).toString('hex');

export function requireThat(condition, message) {
  if (!condition) throw new Error(message);
}

export function openDb(path) {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL;');
  return db;
}

export function transact(db, action) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = action();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

export const walletAddress = publicKey => 'synw_' + sha(publicKey).slice(0, 32);

export function makeIdentity() {
  const keys = generateKeyPairSync('ed25519', {publicKeyEncoding:{type:'spki',format:'pem'},
    privateKeyEncoding:{type:'pkcs8',format:'pem'}});
  return {...keys, address:walletAddress(keys.publicKey)};
}

export function signIntent(identity, action, payload, id = requestId()) {
  const body = {schema:'syntheos.sil-wallet-intent/1',network:NETWORK,mode:MODE,id,
    address:identity.address,publicKey:identity.publicKey,action,payload};
  return {...body, signature:sign(null,Buffer.from(canonical(body)),identity.privateKey).toString('base64')};
}

export function verifiedIntent(value) {
  requireThat(value && typeof value==='object' && typeof value.signature==='string' &&
    /^[A-Za-z0-9+/]{86}==$/.test(value.signature), 'firma_invalida');
  const {signature,...body}=value;
  requireThat(body.network===NETWORK && body.mode===MODE && body.schema==='syntheos.sil-wallet-intent/1' &&
    ID.test(body.id) && typeof body.publicKey==='string' && body.publicKey.length<=128 &&
    body.address===walletAddress(body.publicKey), 'intencion_invalida');
  const key=createPublicKey(body.publicKey);
  requireThat(key.asymmetricKeyType==='ed25519' && verify(null,Buffer.from(canonical(body)),key,Buffer.from(signature,'base64')),
    'firma_invalida');
  requireThat(body.payload && typeof body.payload==='object' && !Array.isArray(body.payload), 'datos_invalidos');
  return body;
}

export function miningHash(id) {
  requireThat(ID.test(id), 'id_invalido');
  return sha(workFor({purpose:'G0_MANIFEST_CHECK',batch:id,index:0,count:1}));
}

export class SilLedger {
  constructor(path) {
    this.db=openDb(path);
    this.db.exec(`CREATE TABLE IF NOT EXISTS accounts(address TEXT PRIMARY KEY, fragments INTEGER NOT NULL,
      chronos INTEGER NOT NULL, role TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS locks(id TEXT PRIMARY KEY, owner TEXT NOT NULL, kind TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY, id TEXT UNIQUE NOT NULL, hash TEXT NOT NULL,
      address TEXT NOT NULL, recipient TEXT, intent TEXT NOT NULL, receipt TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS anchors(seq INTEGER PRIMARY KEY, receipt TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS checkpoint_outbox(slot INTEGER PRIMARY KEY CHECK (slot=1), batch TEXT NOT NULL);`);
  }

  close() { this.db.close(); }

  provision(address, founder) {
    requireThat(WALLET.test(address), 'direccion_invalida');
    transact(this.db,()=>{
      if(founder) {
        const prior=this.db.prepare("SELECT address FROM accounts WHERE role='founder'").get();
        requireThat(!prior||prior.address===address,'fundador_ya_configurado');
      }
      const inserted=this.db.prepare('INSERT OR IGNORE INTO accounts VALUES (?,?,?,?)')
        .run(address,0,founder?16:0,founder?'founder':'wallet').changes;
      if(!founder||!inserted)return;
      for(const kind of ['chronos','licencia'])this.db.prepare('INSERT INTO locks VALUES (?,?,?)').run(kind+':g0:prueba',address,kind);
    });
  }

  account(address) { return this.db.prepare('SELECT * FROM accounts WHERE address=?').get(address); }

  append({intent, ...details}) {
    const previous=this.db.prepare('SELECT seq,hash FROM events ORDER BY seq DESC LIMIT 1').get();
    const record={schema:'syntheos.sil-wallet-receipt/1',mode:MODE,network:NETWORK,seq:(previous?.seq??0)+1,
      previousHash:previous?.hash??ROOT,...details,at:new Date().toISOString()};
    const receipt={...record,hash:sha(canonical(record))};
    this.db.prepare('INSERT INTO events VALUES (?,?,?,?,?,?,?)').run(record.seq,record.id,receipt.hash,
      record.address,record.recipient,JSON.stringify(intent),JSON.stringify(receipt));
    return receipt;
  }

  // Only the integrated node passes receipts from its verified, durable earning records.
  creditCompute(address, receipt) {
    requireThat(WALLET.test(address) && receipt?.schema==='syntheos.compute-settlement/1' && receipt.mode===MODE &&
      ID.test(receipt.id) && ID.test(receipt.batch) && HASH.test(receipt.outputSha256) && receipt.rewardFSynt===10,
      'recibo_computo_invalido');
    validateUsefulWork(receipt);
    const id=computeEntryId(receipt.id);
    const requestHash=sha(canonical(receipt));
    return transact(this.db,()=>{
      const existing=this.db.prepare('SELECT receipt FROM events WHERE id=?').get(id);
      if(existing){
        const result=JSON.parse(existing.receipt);
        requireThat(result.address===address&&result.requestHash===requestHash,'recibo_computo_en_conflicto');
        return result;
      }
      requireThat(this.account(address),'monedero_no_registrado');
      this.db.prepare('UPDATE accounts SET fragments=fragments+? WHERE address=?').run(receipt.rewardFSynt,address);
      return this.append({intent:receipt,id,requestHash,address,recipient:null,action:'cobro',units:receipt.rewardFSynt,
        sourceId:receipt.id,batch:receipt.batch});
    });
  }

  stage(intent) {
    const body=verifiedIntent(intent);
    const {address, action, payload, id}=body;
    requireThat(action==='minar'||action==='enviar'||action==='compartir','accion_desconocida');
    const requestHash=sha(canonical(intent));
    const proof=action==='minar'?miningHash(id):null;
    return transact(this.db,()=>{
      const prior=this.db.prepare('SELECT receipt FROM events WHERE id=?').get(id);
      if(prior){
        const receipt=JSON.parse(prior.receipt);
        requireThat(receipt.requestHash===requestHash,'operacion_en_conflicto');
        return receipt;
      }
      const account=this.account(address);
      requireThat(account,'monedero_no_registrado');
      let recipient=null;
      let units=0;
      if(action==='minar') {
        requireThat(payload.proof===proof && (payload.compute==='CPU_LOCAL'||payload.compute==='MYCELIAL'),
          'prueba_de_computo_invalida');
        requireThat(payload.workReceiptId===undefined ||
          (payload.compute==='MYCELIAL'&&typeof payload.workReceiptId==='string'&&ID.test(payload.workReceiptId)),
          'recibo_pouw_invalido');
        requireThat(account.role==='founder' && account.chronos>=1,'g0_requiere_fundador_y_chronos');
        requireThat(this.db.prepare('SELECT COUNT(*) AS n FROM locks WHERE owner=?').get(address).n===2,'faltan_softnft_bloqueados');
        const mined=this.db.prepare("SELECT COUNT(*) AS n FROM events WHERE address=? AND json_extract(receipt,'$.action')='minar'").get(address).n;
        requireThat(mined<GENESIS_LIMIT,'limite_g0_del_piloto');
        this.db.prepare('UPDATE accounts SET fragments=fragments+1,chronos=chronos-1 WHERE address=?').run(address);
        units=1;
      } else if(action==='enviar') {
        ({recipient,units}=payload);
        requireThat(WALLET.test(recipient) && recipient!==address && this.account(recipient),'destino_no_registrado');
        requireThat(Number.isSafeInteger(units) && units>0 && units<=account.fragments,'saldo_insuficiente');
        this.db.prepare('UPDATE accounts SET fragments=fragments-? WHERE address=?').run(units,address);
        this.db.prepare('UPDATE accounts SET fragments=fragments+? WHERE address=?').run(units,recipient);
      } else {
        requireThat(typeof payload.enabled==='boolean','permiso_de_computo_invalido');
      }
      return this.append({intent,id,requestHash,address,recipient,action,units,
        ...(action==='compartir'?{enabled:payload.enabled}:{}),
        ...(action==='minar'?{chronos:1,compute:payload.compute,
          ...(payload.workReceiptId?{workReceiptId:payload.workReceiptId}:{})}:{})});
    });
  }

  snapshot(address) {
    const account=this.account(address);
    requireThat(account,'monedero_no_registrado');
    const locks=this.db.prepare('SELECT id,kind FROM locks WHERE owner=? ORDER BY kind').all(address);
    const records=this.db.prepare(`SELECT e.receipt, a.receipt AS anchor FROM events e LEFT JOIN anchors a USING(seq)
      WHERE e.address=? OR e.recipient=? ORDER BY e.seq DESC LIMIT 100`).all(address,address);
    const earnings=this.db.prepare(`SELECT COUNT(*) AS jobs,COALESCE(SUM(json_extract(receipt,'$.units')),0) AS fragments
      FROM events WHERE address=? AND json_extract(receipt,'$.action')='cobro'`).get(address);
    const g0Mined=Boolean(this.db.prepare(`SELECT 1 FROM events WHERE address=? AND json_extract(receipt,'$.action')='minar' LIMIT 1`).get(address));
    return {mode:MODE,network:NETWORK,address,balance:account.fragments,chronos:account.chronos,founder:account.role==='founder',g0Mined,earnings,
      locks,records:records.map(row=>({...JSON.parse(row.receipt),
        ...(row.anchor?{anchor:JSON.parse(row.anchor),state:'CHECKPOINT_PILOTO'}:{state:'ACEPTADO_EN_SIL'})}))};
  }

  usefulWorkAccount(address, receipts) {
    const summary={acceptedJobs:0,legacyJobs:0,chronos:0,computeCostFSynt:0,
      genesis:{fragments:0,attributedCostFSynt:0,attributedChronos:0,pendingJobs:0},
      preview:{pixels:0,pixelsPerPreview:PREVIEW_PIXELS,attributedCostFSynt:0,attributedChronos:0}};
    const find=this.db.prepare('SELECT address, intent, receipt FROM events WHERE id=?');
    const entries=[];
    for(const receipt of receipts){
      const work=validateUsefulWork(receipt);
      if(!work){summary.legacyJobs++;continue;}
      const credited=find.get(computeEntryId(receipt.id));
      const result=work.purpose==='G0_MANIFEST_CHECK'?find.get(receipt.batch):null;
      const issuance=result?JSON.parse(result.receipt):null;
      const request=result?JSON.parse(result.intent):null;
      const attributable=work.count===1 && issuance?.action==='minar' && issuance.workReceiptId===receipt.id &&
        request?.payload?.proof===receipt.outputSha256;
      const fragments=attributable?issuance.units:0;
      const pixels=work.purpose==='FORGE_PREVIEW'?previewPixels(work):0;
      summary.acceptedJobs++;
      summary.chronos+=receipt.consumedChronos;
      summary.computeCostFSynt+=receipt.rewardFSynt;
      summary.genesis.fragments+=fragments;
      summary.preview.pixels+=pixels;
      if(fragments){
        summary.genesis.attributedCostFSynt+=receipt.rewardFSynt;
        summary.genesis.attributedChronos+=receipt.consumedChronos;
      } else if(work.purpose==='G0_MANIFEST_CHECK')summary.genesis.pendingJobs++;
      if(pixels){
        summary.preview.attributedCostFSynt+=receipt.rewardFSynt;
        summary.preview.attributedChronos+=receipt.consumedChronos;
      }
      entries.push({id:receipt.id,batch:receipt.batch,purpose:work.purpose,profile:work.profile,
        elapsedMs:work.elapsedMs,chronos:receipt.consumedChronos,costFSynt:receipt.rewardFSynt,
        credited:credited?.address===address,fragments,pixels,
        proofHash:work.proofHash,outputSha256:receipt.outputSha256});
    }
    return {summary,entries:entries.slice(-12).reverse()};
  }

  nextCheckpoint() {
    return transact(this.db,()=>{
      const prior=this.db.prepare('SELECT batch FROM checkpoint_outbox WHERE slot=1').get();
      if(prior)return JSON.parse(prior.batch);
      const rows=this.db.prepare(`SELECT e.seq,e.hash FROM events e LEFT JOIN anchors a USING(seq)
        WHERE a.seq IS NULL ORDER BY e.seq LIMIT 50`).all();
      if(!rows.length)return null;
      const body={schema:'syntheos.wallet-checkpoint-pilot/1',network:NETWORK,mode:MODE,events:rows.map(row=>({...row}))};
      const batch={...body,id:sha(canonical(body))};
      this.db.prepare('INSERT INTO checkpoint_outbox VALUES (1,?)').run(JSON.stringify(batch));
      return batch;
    });
  }

  markCheckpoint(batch, receipt) {
    const {hash,...body}=receipt??{};
    requireThat(body.id===batch.id && body.mode===MODE && HASH.test(hash) && hash===sha(canonical(body)) &&
      body.first===batch.events[0].seq && body.last===batch.events.at(-1).seq && body.events===batch.events.length,
      'recibo_checkpoint_invalido');
    transact(this.db,()=>{
      for(const event of batch.events) {
        requireThat(this.db.prepare('SELECT hash FROM events WHERE seq=?').get(event.seq)?.hash===event.hash,'lote_no_coincide');
        const prior=this.db.prepare('SELECT receipt FROM anchors WHERE seq=?').get(event.seq);
        requireThat(!prior||JSON.parse(prior.receipt).id===batch.id,'lote_en_conflicto');
        this.db.prepare('INSERT OR IGNORE INTO anchors VALUES (?,?)').run(event.seq,JSON.stringify(receipt));
      }
      const pending=this.db.prepare('SELECT batch FROM checkpoint_outbox WHERE slot=1').get();
      if(pending&&JSON.parse(pending.batch).id===batch.id)this.db.prepare('DELETE FROM checkpoint_outbox WHERE slot=1').run();
    });
  }
}
